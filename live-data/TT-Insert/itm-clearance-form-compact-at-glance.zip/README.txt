DEVICE CLEARANCE / EMPLOYEE LIFECYCLE FORM
COMPACT AT-A-GLANCE DESIGN

Changes:
- Reduced outer padding and vertical gaps.
- Compact section headers and bodies.
- Smaller inputs and employee photo.
- Compact Joining preparation cards.
- Compact IT assignment and notes.
- Removed horizontal scrolling from assigned-device area.
- Desktop device table stays within card width.
- Small screens use responsive device cards.
- No backend or PostgreSQL changes required.
