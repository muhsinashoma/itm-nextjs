#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(pwd)}"
if [ ! -d "$ROOT/frontend/app" ]; then echo "ERROR: frontend/app not found under: $ROOT"; exit 1; fi
ACTIVE="$ROOT/frontend/app/dashboard/device-clearance/clearance-form/page.tsx"
CREATE="$ROOT/frontend/app/dashboard/device-clearance/create/page.tsx"
mkdir -p "$(dirname "$ACTIVE")" "$(dirname "$CREATE")"
for f in "$ACTIVE" "$CREATE"; do if [ -f "$f" ]; then cp "$f" "$f.bak"; echo "Backup: $f.bak"; fi; done
cp "$PKG_DIR/frontend/app/dashboard/device-clearance/clearance-form/page.tsx" "$ACTIVE"
cp "$PKG_DIR/frontend/app/dashboard/device-clearance/create/page.tsx" "$CREATE"
echo "Installed compact at-a-glance lifecycle form."
echo "No backend or database changes required."
