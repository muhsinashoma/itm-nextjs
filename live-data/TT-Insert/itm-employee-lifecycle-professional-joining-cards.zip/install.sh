#!/usr/bin/env bash
set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(pwd)}"

if [ ! -d "$ROOT/frontend/app" ]; then
    echo "ERROR: frontend/app not found under: $ROOT"
    exit 1
fi

if [ -d "$ROOT/itm/backend/internal/handler" ]; then
    BACKEND_DIR="$ROOT/itm/backend/internal/handler"
else
    BACKEND_DIR="$ROOT/backend/internal/handler"
fi

FILES=(
    "$BACKEND_DIR/handlers.go"
    "$BACKEND_DIR/device_clearance.go"
    "$ROOT/frontend/app/dashboard/device-clearance/clearance-form/page.tsx"
    "$ROOT/frontend/app/dashboard/device-clearance/create/page.tsx"
    "$ROOT/frontend/app/dashboard/device-clearance/approval/[id]/page.tsx"
    "$ROOT/frontend/app/dashboard/device-clearance/clearance-list/page.tsx"
)

for file in "${FILES[@]}"; do
    mkdir -p "$(dirname "$file")"

    if [ -f "$file" ]; then
        cp "$file" "$file.bak"
        echo "Backup: $file.bak"
    fi
done

cp \
    "$PKG_DIR/itm/backend/internal/handler/handlers.go" \
    "$BACKEND_DIR/handlers.go"

cp \
    "$PKG_DIR/itm/backend/internal/handler/device_clearance.go" \
    "$BACKEND_DIR/device_clearance.go"

cp \
    "$PKG_DIR/frontend/app/dashboard/device-clearance/clearance-form/page.tsx" \
    "$ROOT/frontend/app/dashboard/device-clearance/clearance-form/page.tsx"

cp \
    "$PKG_DIR/frontend/app/dashboard/device-clearance/create/page.tsx" \
    "$ROOT/frontend/app/dashboard/device-clearance/create/page.tsx"

cp \
    "$PKG_DIR/frontend/app/dashboard/device-clearance/approval/[id]/page.tsx" \
    "$ROOT/frontend/app/dashboard/device-clearance/approval/[id]/page.tsx"

cp \
    "$PKG_DIR/frontend/app/dashboard/device-clearance/clearance-list/page.tsx" \
    "$ROOT/frontend/app/dashboard/device-clearance/clearance-list/page.tsx"

echo
echo "Files installed."
echo
echo "NOW RUN THIS SQL IN pgAdmin:"
echo "  $PKG_DIR/database/003_employee_lifecycle_joining_exit_card_access.sql"
echo
echo "Then restart backend and frontend."
