-- ============================================================
-- EMPLOYEE IT LIFECYCLE
-- Joining + Exit + Card Access
--
-- Safe to run multiple times.
-- ============================================================

BEGIN;

-- Professional lifecycle naming.
ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS request_type VARCHAR(30);

ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS effective_date DATE;

-- Joining / onboarding actions.
ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS device_assigned BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS vpn_access_enabled BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS ip_phone_enabled BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS printer_access_enabled BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS endpoint_security_installed BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS card_access_enabled BOOLEAN NOT NULL DEFAULT FALSE;

-- Exit / offboarding: add Card Access to your existing checklist.
ALTER TABLE public.device_clearances
    ADD COLUMN IF NOT EXISTS card_access_removed BOOLEAN NOT NULL DEFAULT FALSE;

-- Backfill current data from the old field names.
UPDATE public.device_clearances
SET
    request_type =
        CASE
            WHEN LOWER(BTRIM(COALESCE(separation_mode,''))) = 'joining'
                THEN 'Joining'

            WHEN LOWER(BTRIM(COALESCE(separation_mode,''))) = 'retirement'
                THEN 'Retirement'

            WHEN LOWER(BTRIM(COALESCE(separation_mode,''))) IN ('contract end','contract_end','contract-end')
                THEN 'Contract End'

            WHEN LOWER(BTRIM(COALESCE(separation_mode,''))) = 'termination'
                THEN 'Termination'

            WHEN LOWER(BTRIM(COALESCE(separation_mode,''))) = 'other'
                THEN 'Other'

            ELSE 'Resignation'
        END
WHERE
    request_type IS NULL
    OR BTRIM(request_type) = '';

UPDATE public.device_clearances
SET
    effective_date =
        COALESCE(
            effective_date,
            resignation_date
        )
WHERE
    effective_date IS NULL;

-- Keep old fields populated for backward compatibility.
UPDATE public.device_clearances
SET
    separation_mode =
        COALESCE(
            NULLIF(BTRIM(separation_mode),''),
            request_type
        ),

    resignation_date =
        COALESCE(
            resignation_date,
            effective_date
        );

ALTER TABLE public.device_clearances
    ALTER COLUMN request_type SET DEFAULT 'Resignation';

CREATE INDEX IF NOT EXISTS
idx_device_clearances_request_type
ON public.device_clearances(request_type);

CREATE INDEX IF NOT EXISTS
idx_device_clearances_effective_date
ON public.device_clearances(effective_date DESC);

COMMIT;


-- ============================================================
-- VERIFY
-- ============================================================

SELECT
    id,
    reference_no,
    request_type,
    effective_date,
    employee_id,
    employee_name,
    assigned_to_name,
    status,

    device_assigned,
    vpn_access_enabled,
    ip_phone_enabled,
    printer_access_enabled,
    endpoint_security_installed,
    card_access_enabled,

    device_returned,
    vpn_removed,
    ip_phone_disabled,
    printer_access_removed,
    panda_removed,
    card_access_removed

FROM public.device_clearances

ORDER BY id DESC

LIMIT 50;
