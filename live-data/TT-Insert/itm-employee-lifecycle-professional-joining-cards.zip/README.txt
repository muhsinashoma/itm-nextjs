EMPLOYEE IT LIFECYCLE
JOINING + EXIT + CARD ACCESS
================================

GOAL
----

This package turns Device Clearance into one professional employee IT lifecycle
workflow.

The creator only:

1. selects lifecycle event,
2. selects employee,
3. selects effective date,
4. assigns responsible IT personnel,
5. adds notes,
6. creates the task.

The assigned IT employee performs the operational work later.


JOINING CHECKLIST
-----------------

For Joining, the assigned IT employee sees:

1. Device Assigned
   Assign and configure required IT equipment.

2. VPN Access Enabled
   Enable VPN access if required.

3. IP Phone Enabled
   Create / activate IP phone extension.

4. Printer Access Enabled
   Grant printer / print-server access.

5. Endpoint Security Installed
   Install / activate Panda endpoint security.

6. Card Access Enabled
   Activate employee physical access card.


EXIT / RESIGNATION CHECKLIST
----------------------------

For Resignation, Retirement, Contract End, Termination and Other:

1. Device Returned
   Confirm all assigned IT equipment has been returned.

2. VPN Access Removed
   Revoke VPN access.

3. IP Phone Disabled
   Disable IP phone / extension.

4. Printer Access Removed
   Revoke print-server access.

5. Endpoint Security Removed
   Remove Panda / endpoint security profile where applicable.

6. Card Access Disabled
   Deactivate employee physical access card.


DEVICE SOURCE OF TRUTH
----------------------

The checklist does NOT directly change it_equipment.

Your existing inventory process remains the source of truth.

On EXIT completion, the backend refuses completion if a device still has:

    status = '1'

or:

    status = 'Assigned'

for that employee.

So the actual inventory device must first be Returned / Transferred using the
existing inventory workflow.


DATABASE
--------

Run:

    database/003_employee_lifecycle_joining_exit_card_access.sql

This adds:

    request_type
    effective_date

Joining:
    device_assigned
    vpn_access_enabled
    ip_phone_enabled
    printer_access_enabled
    endpoint_security_installed
    card_access_enabled

Exit:
    card_access_removed

Your existing exit columns are reused:

    device_returned
    vpn_removed
    ip_phone_disabled
    printer_access_removed
    panda_removed


BACKEND
-------

Replace:

    itm/backend/internal/handler/handlers.go
    itm/backend/internal/handler/device_clearance.go

Routes remain:

    POST   /device-clearances
    GET    /device-clearances
    GET    /device-clearances/:id
    PATCH  /device-clearances/:id/checklist
    PATCH  /device-clearances/:id/complete


FRONTEND
--------

Replace:

    frontend/app/dashboard/device-clearance/clearance-form/page.tsx
    frontend/app/dashboard/device-clearance/create/page.tsx
    frontend/app/dashboard/device-clearance/approval/[id]/page.tsx
    frontend/app/dashboard/device-clearance/clearance-list/page.tsx


IMPORTANT WORKFLOW RULE
-----------------------

Joining:
    IT person checks setup items and completes the task.

Exit:
    IT person checks deactivation / return items.
    Backend also verifies that no device remains assigned.


INSTALL
-------

1. Run the SQL in pgAdmin.

2. Copy the package files manually, or run:

       chmod +x install.sh
       ./install.sh /path/to/your/ITM-project

3. Restart Go backend.

4. Restart frontend.


NOTE ABOUT OLD DATA
-------------------

The migration backfills existing rows:

    request_type <- separation_mode
    effective_date <- resignation_date

So your existing clearance records continue to work.


PROFESSIONAL JOINING PREPARATION CARDS
--------------------------------------

The Joining creation screen now shows exactly six professional setup cards:

1. Device Assigned
2. VPN Access
3. IP Phone
4. Printer Access
5. Endpoint Security
6. Card Access

Each card is intentionally read-only on the creation screen and marked as
"Assigned IT action". The responsible IT employee completes the real checklist
on the task/detail page after assignment.
