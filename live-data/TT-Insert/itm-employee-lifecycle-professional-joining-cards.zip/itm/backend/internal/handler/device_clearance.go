package handler

import (
	"fmt"
	"strconv"
	"strings"

	"itm-api/pkg/response"

	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5"
)

const (
	lifecycleJoining     = "Joining"
	lifecycleResignation = "Resignation"
	lifecycleRetirement  = "Retirement"
	lifecycleContractEnd = "Contract End"
	lifecycleTermination = "Termination"
	lifecycleOther       = "Other"
)

type lifecycleEmployeeSnapshot struct {
	EmployeeID   string
	EmployeeName string
	Designation  string
	Department   string
	WorkField    string
	Phone        string
	Email        string
	Picture      string
}

type lifecycleChecklist struct {
	// Joining / onboarding
	DeviceAssigned            bool `json:"device_assigned"`
	VPNAccessEnabled          bool `json:"vpn_access_enabled"`
	IPPhoneEnabled            bool `json:"ip_phone_enabled"`
	PrinterAccessEnabled      bool `json:"printer_access_enabled"`
	EndpointSecurityInstalled bool `json:"endpoint_security_installed"`
	CardAccessEnabled         bool `json:"card_access_enabled"`

	// Exit / offboarding
	DeviceReturned       bool `json:"device_returned"`
	VPNRemoved           bool `json:"vpn_removed"`
	IPPhoneDisabled      bool `json:"ip_phone_disabled"`
	PrinterAccessRemoved bool `json:"printer_access_removed"`
	PandaRemoved         bool `json:"panda_removed"`
	CardAccessRemoved    bool `json:"card_access_removed"`
}

func normalizeLifecycleType(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "joining":
		return lifecycleJoining
	case "resignation":
		return lifecycleResignation
	case "retirement":
		return lifecycleRetirement
	case "contract end", "contract_end", "contract-end":
		return lifecycleContractEnd
	case "termination":
		return lifecycleTermination
	case "other":
		return lifecycleOther
	default:
		return lifecycleResignation
	}
}

func isJoiningLifecycle(value string) bool {
	return normalizeLifecycleType(value) == lifecycleJoining
}

func checklistStarted(requestType string, c lifecycleChecklist) bool {
	if isJoiningLifecycle(requestType) {
		return c.DeviceAssigned ||
			c.VPNAccessEnabled ||
			c.IPPhoneEnabled ||
			c.PrinterAccessEnabled ||
			c.EndpointSecurityInstalled ||
			c.CardAccessEnabled
	}

	return c.DeviceReturned ||
		c.VPNRemoved ||
		c.IPPhoneDisabled ||
		c.PrinterAccessRemoved ||
		c.PandaRemoved ||
		c.CardAccessRemoved
}

func checklistComplete(requestType string, c lifecycleChecklist) bool {
	if isJoiningLifecycle(requestType) {
		return c.DeviceAssigned &&
			c.VPNAccessEnabled &&
			c.IPPhoneEnabled &&
			c.PrinterAccessEnabled &&
			c.EndpointSecurityInstalled &&
			c.CardAccessEnabled
	}

	return c.DeviceReturned &&
		c.VPNRemoved &&
		c.IPPhoneDisabled &&
		c.PrinterAccessRemoved &&
		c.PandaRemoved &&
		c.CardAccessRemoved
}

func lifecycleStatusFromChecklist(requestType string, c lifecycleChecklist) string {
	if checklistStarted(requestType, c) {
		return "In Process"
	}
	return "Pending Clearance"
}

func (h *DashboardHandler) getLifecycleEmployee(
	c *gin.Context,
	employeeID string,
) (lifecycleEmployeeSnapshot, error) {
	var e lifecycleEmployeeSnapshot

	err := h.db.QueryRow(
		c.Request.Context(),
		`
		SELECT
			BTRIM(COALESCE(o.employee_id,'')),
			BTRIM(COALESCE(o.employee_name,'')),
			BTRIM(COALESCE(o.designation,'')),
			BTRIM(COALESCE(o.department_name,'')),
			BTRIM(COALESCE(o.work_field,'')),
			COALESCE(
				NULLIF(BTRIM(COALESCE(p.official_cell_no,'')),''),
				NULLIF(BTRIM(COALESCE(p.personal_cell_no,'')),''),
				''
			),
			COALESCE(
				NULLIF(BTRIM(COALESCE(p.official_email,'')),''),
				NULLIF(BTRIM(COALESCE(p.email,'')),''),
				''
			),
			BTRIM(COALESCE(p.picture,''))
		FROM public.employee_office_info o
		LEFT JOIN public.employee_personal_info p
			ON BTRIM(COALESCE(p.employee_id,'')) =
			   BTRIM(COALESCE(o.employee_id,''))
		WHERE BTRIM(COALESCE(o.employee_id,''))=$1
		LIMIT 1
		`,
		strings.TrimSpace(employeeID),
	).Scan(
		&e.EmployeeID,
		&e.EmployeeName,
		&e.Designation,
		&e.Department,
		&e.WorkField,
		&e.Phone,
		&e.Email,
		&e.Picture,
	)

	return e, err
}

func (h *DashboardHandler) CreateDeviceClearance(c *gin.Context) {
	ctx := c.Request.Context()

	var body struct {
		RequestType   string `json:"request_type"`
		EffectiveDate string `json:"effective_date"`

		// Backward compatibility with the previous form/API.
		ResignationDate string `json:"resignation_date"`
		SeparationMode  string `json:"separation_mode"`

		EmployeeID string `json:"employee_id"`
		AssignedTo string `json:"assigned_to"`
		Remarks    string `json:"remarks"`
	}

	if err := c.ShouldBindJSON(&body); err != nil {
		response.BadRequest(c, "invalid request body")
		return
	}

	requestType := normalizeLifecycleType(body.RequestType)
	if strings.TrimSpace(body.RequestType) == "" {
		requestType = normalizeLifecycleType(body.SeparationMode)
	}

	effectiveDate := strings.TrimSpace(body.EffectiveDate)
	if effectiveDate == "" {
		effectiveDate = strings.TrimSpace(body.ResignationDate)
	}

	body.EmployeeID = strings.TrimSpace(body.EmployeeID)
	body.AssignedTo = strings.TrimSpace(body.AssignedTo)
	body.Remarks = strings.TrimSpace(body.Remarks)

	if body.EmployeeID == "" {
		response.BadRequest(c, "employee_id is required")
		return
	}

	if body.AssignedTo == "" {
		response.BadRequest(c, "assigned_to is required")
		return
	}

	if effectiveDate == "" {
		response.BadRequest(c, "effective_date is required")
		return
	}

	if body.EmployeeID == body.AssignedTo {
		response.BadRequest(c, "the employee cannot be assigned as their own IT lifecycle owner")
		return
	}

	createdBy := strings.TrimSpace(c.GetString("employee_id"))
	if createdBy == "" {
		response.BadRequest(c, "authenticated employee ID is missing")
		return
	}

	employee, err := h.getLifecycleEmployee(c, body.EmployeeID)
	if err != nil {
		if err == pgx.ErrNoRows {
			response.BadRequest(c, "selected employee was not found")
			return
		}
		response.ServerError(c, err)
		return
	}

	assignee, err := h.getLifecycleEmployee(c, body.AssignedTo)
	if err != nil {
		if err == pgx.ErrNoRows {
			response.BadRequest(c, "assigned IT employee was not found")
			return
		}
		response.ServerError(c, err)
		return
	}

	var validAssignee bool
	if err := h.db.QueryRow(
		ctx,
		`
		SELECT EXISTS(
			SELECT 1
			FROM public.employee_office_info
			WHERE BTRIM(COALESCE(employee_id,''))=$1
			  AND UPPER(BTRIM(COALESCE(work_field,'')))='IT'
			  AND LOWER(BTRIM(COALESCE(active,''))) IN ('active','yes')
		)
		`,
		body.AssignedTo,
	).Scan(&validAssignee); err != nil {
		response.ServerError(c, err)
		return
	}

	if !validAssignee {
		response.BadRequest(c, "assigned employee must be an active IT employee")
		return
	}

	/*
		Do not allow two unfinished lifecycle tasks of the same type
		for the same employee.
	*/
	var openID int64
	err = h.db.QueryRow(
		ctx,
		`
		SELECT id
		FROM public.device_clearances
		WHERE employee_id=$1
		  AND request_type=$2
		  AND deleted_at IS NULL
		  AND status IN ('Pending Clearance','In Process')
		ORDER BY id DESC
		LIMIT 1
		`,
		body.EmployeeID,
		requestType,
	).Scan(&openID)

	if err == nil {
		response.BadRequest(
			c,
			fmt.Sprintf(
				"an open %s task already exists for this employee (ID %d)",
				requestType,
				openID,
			),
		)
		return
	}

	if err != pgx.ErrNoRows {
		response.ServerError(c, err)
		return
	}

	createdByName := ""
	_ = h.db.QueryRow(
		ctx,
		`
		SELECT BTRIM(COALESCE(employee_name,''))
		FROM public.employee_office_info
		WHERE BTRIM(COALESCE(employee_id,''))=$1
		LIMIT 1
		`,
		createdBy,
	).Scan(&createdByName)

	var id int64
	var ref string

	err = h.db.QueryRow(
		ctx,
		`
		INSERT INTO public.device_clearances (
			request_type,
			effective_date,

			employee_id,
			employee_name,
			designation,
			department,
			work_field,
			phone,
			email,
			employee_picture,

			resignation_date,
			separation_mode,
			remarks,

			assigned_to,
			assigned_to_name,
			assigned_at,

			device_assigned,
			vpn_access_enabled,
			ip_phone_enabled,
			printer_access_enabled,
			endpoint_security_installed,
			card_access_enabled,

			device_returned,
			vpn_removed,
			ip_phone_disabled,
			printer_access_removed,
			panda_removed,
			card_access_removed,

			ec_given,
			status,

			created_by,
			created_by_name,
			created_at,

			updated_by,
			updated_by_name,
			updated_at
		)
		VALUES (
			$1,
			$2::date,

			$3,$4,$5,$6,$7,$8,$9,$10,

			$2::date,
			$1,
			NULLIF($11,''),

			$12,$13,CURRENT_TIMESTAMP,

			FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,

			FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,

			FALSE,
			'Pending Clearance',

			$14,
			NULLIF($15,''),
			CURRENT_TIMESTAMP,

			$14,
			NULLIF($15,''),
			CURRENT_TIMESTAMP
		)
		RETURNING id, reference_no
		`,
		requestType,
		effectiveDate,

		employee.EmployeeID,
		employee.EmployeeName,
		employee.Designation,
		employee.Department,
		employee.WorkField,
		employee.Phone,
		employee.Email,
		employee.Picture,

		body.Remarks,

		assignee.EmployeeID,
		assignee.EmployeeName,

		createdBy,
		createdByName,
	).Scan(&id, &ref)

	if err != nil {
		response.ServerError(c, err)
		return
	}

	response.Created(
		c,
		gin.H{
			"id":             id,
			"reference_no":   ref,
			"status":         "Pending Clearance",
			"request_type":   requestType,
			"effective_date": effectiveDate,
		},
	)
}

func (h *DashboardHandler) ListDeviceClearances(c *gin.Context) {
	ctx := c.Request.Context()

	status := strings.TrimSpace(c.Query("status"))
	requestType := strings.TrimSpace(c.Query("request_type"))
	search := strings.TrimSpace(c.Query("search"))

	rows, err := h.db.Query(
		ctx,
		`
		SELECT
			id,
			COALESCE(reference_no,''),
			COALESCE(request_type,'Resignation'),
			COALESCE(effective_date::text, resignation_date::text, ''),

			COALESCE(employee_id,''),
			COALESCE(employee_name,''),
			COALESCE(designation,''),
			COALESCE(department,''),

			COALESCE(assigned_to,''),
			COALESCE(assigned_to_name,''),

			COALESCE(status,''),
			COALESCE(created_at::text,''),
			COALESCE(completed_at::text,'')
		FROM public.device_clearances
		WHERE deleted_at IS NULL
		  AND ($1='' OR status=$1)
		  AND ($2='' OR request_type=$2)
		  AND (
				$3=''
				OR employee_id ILIKE '%' || $3 || '%'
				OR employee_name ILIKE '%' || $3 || '%'
				OR reference_no ILIKE '%' || $3 || '%'
		  )
		ORDER BY id DESC
		LIMIT 500
		`,
		status,
		requestType,
		search,
	)

	if err != nil {
		response.ServerError(c, err)
		return
	}
	defer rows.Close()

	items := make([]gin.H, 0)

	for rows.Next() {
		var id int64
		var ref, itemType, effectiveDate string
		var employeeID, employeeName, designation, department string
		var assignedTo, assignedToName, itemStatus, createdAt, completedAt string

		if err := rows.Scan(
			&id,
			&ref,
			&itemType,
			&effectiveDate,
			&employeeID,
			&employeeName,
			&designation,
			&department,
			&assignedTo,
			&assignedToName,
			&itemStatus,
			&createdAt,
			&completedAt,
		); err != nil {
			response.ServerError(c, err)
			return
		}

		items = append(
			items,
			gin.H{
				"id":               id,
				"reference_no":     ref,
				"request_type":     itemType,
				"effective_date":   effectiveDate,
				"resignation_date": effectiveDate,

				"employee_id":   employeeID,
				"employee_name": employeeName,
				"designation":   designation,
				"department":    department,

				"assigned_to":      assignedTo,
				"assigned_to_name": assignedToName,

				"status":       itemStatus,
				"created_at":   createdAt,
				"completed_at": completedAt,
			},
		)
	}

	if err := rows.Err(); err != nil {
		response.ServerError(c, err)
		return
	}

	response.OK(c, items)
}

func (h *DashboardHandler) GetDeviceClearance(c *gin.Context) {
	id, err := strconv.ParseInt(strings.TrimSpace(c.Param("id")), 10, 64)
	if err != nil || id <= 0 {
		response.BadRequest(c, "invalid lifecycle request id")
		return
	}

	type item struct {
		ReferenceNo   string
		RequestType   string
		EffectiveDate string

		EmployeeID   string
		EmployeeName string
		Designation  string
		Department   string
		WorkField    string
		Phone        string
		Email        string
		Picture      string

		Remarks        string
		AssignedTo     string
		AssignedToName string

		Checklist lifecycleChecklist
		ECGiven   bool
		Status    string

		CreatedBy     string
		CreatedByName string
		CreatedAt     string
		CompletedBy   string
		CompletedName string
		CompletedAt   string
	}

	var row item

	err = h.db.QueryRow(
		c.Request.Context(),
		`
		SELECT
			COALESCE(reference_no,''),
			COALESCE(request_type,'Resignation'),
			COALESCE(effective_date::text, resignation_date::text, ''),

			COALESCE(employee_id,''),
			COALESCE(employee_name,''),
			COALESCE(designation,''),
			COALESCE(department,''),
			COALESCE(work_field,''),
			COALESCE(phone,''),
			COALESCE(email,''),
			COALESCE(employee_picture,''),

			COALESCE(remarks,''),
			COALESCE(assigned_to,''),
			COALESCE(assigned_to_name,''),

			COALESCE(device_assigned,FALSE),
			COALESCE(vpn_access_enabled,FALSE),
			COALESCE(ip_phone_enabled,FALSE),
			COALESCE(printer_access_enabled,FALSE),
			COALESCE(endpoint_security_installed,FALSE),
			COALESCE(card_access_enabled,FALSE),

			COALESCE(device_returned,FALSE),
			COALESCE(vpn_removed,FALSE),
			COALESCE(ip_phone_disabled,FALSE),
			COALESCE(printer_access_removed,FALSE),
			COALESCE(panda_removed,FALSE),
			COALESCE(card_access_removed,FALSE),

			COALESCE(ec_given,FALSE),
			COALESCE(status,''),

			COALESCE(created_by,''),
			COALESCE(created_by_name,''),
			COALESCE(created_at::text,''),

			COALESCE(completed_by,''),
			COALESCE(completed_by_name,''),
			COALESCE(completed_at::text,'')
		FROM public.device_clearances
		WHERE id=$1
		  AND deleted_at IS NULL
		`,
		id,
	).Scan(
		&row.ReferenceNo,
		&row.RequestType,
		&row.EffectiveDate,

		&row.EmployeeID,
		&row.EmployeeName,
		&row.Designation,
		&row.Department,
		&row.WorkField,
		&row.Phone,
		&row.Email,
		&row.Picture,

		&row.Remarks,
		&row.AssignedTo,
		&row.AssignedToName,

		&row.Checklist.DeviceAssigned,
		&row.Checklist.VPNAccessEnabled,
		&row.Checklist.IPPhoneEnabled,
		&row.Checklist.PrinterAccessEnabled,
		&row.Checklist.EndpointSecurityInstalled,
		&row.Checklist.CardAccessEnabled,

		&row.Checklist.DeviceReturned,
		&row.Checklist.VPNRemoved,
		&row.Checklist.IPPhoneDisabled,
		&row.Checklist.PrinterAccessRemoved,
		&row.Checklist.PandaRemoved,
		&row.Checklist.CardAccessRemoved,

		&row.ECGiven,
		&row.Status,

		&row.CreatedBy,
		&row.CreatedByName,
		&row.CreatedAt,

		&row.CompletedBy,
		&row.CompletedName,
		&row.CompletedAt,
	)

	if err != nil {
		if err == pgx.ErrNoRows {
			response.NotFound(c, "lifecycle request not found")
			return
		}
		response.ServerError(c, err)
		return
	}

	var assignedDevices int
	_ = h.db.QueryRow(
		c.Request.Context(),
		`
		SELECT COUNT(*)::int
		FROM public.it_equipment
		WHERE BTRIM(COALESCE(emp_id,''))=$1
		  AND COALESCE(active,0)>0
		  AND (
				BTRIM(COALESCE(status,''))='1'
				OR LOWER(BTRIM(COALESCE(status,'')))='assigned'
		  )
		`,
		row.EmployeeID,
	).Scan(&assignedDevices)

	response.OK(
		c,
		gin.H{
			"id":             id,
			"reference_no":   row.ReferenceNo,
			"request_type":   row.RequestType,
			"effective_date": row.EffectiveDate,

			// Backward compatible aliases
			"separation_mode":  row.RequestType,
			"resignation_date": row.EffectiveDate,

			"employee_id":      row.EmployeeID,
			"employee_name":    row.EmployeeName,
			"designation":      row.Designation,
			"department":       row.Department,
			"work_field":       row.WorkField,
			"phone":            row.Phone,
			"email":            row.Email,
			"employee_picture": row.Picture,

			"remarks":          row.Remarks,
			"assigned_to":      row.AssignedTo,
			"assigned_to_name": row.AssignedToName,

			"device_assigned":             row.Checklist.DeviceAssigned,
			"vpn_access_enabled":          row.Checklist.VPNAccessEnabled,
			"ip_phone_enabled":            row.Checklist.IPPhoneEnabled,
			"printer_access_enabled":      row.Checklist.PrinterAccessEnabled,
			"endpoint_security_installed": row.Checklist.EndpointSecurityInstalled,
			"card_access_enabled":         row.Checklist.CardAccessEnabled,

			"device_returned":        row.Checklist.DeviceReturned,
			"vpn_removed":            row.Checklist.VPNRemoved,
			"ip_phone_disabled":      row.Checklist.IPPhoneDisabled,
			"printer_access_removed": row.Checklist.PrinterAccessRemoved,
			"panda_removed":          row.Checklist.PandaRemoved,
			"card_access_removed":    row.Checklist.CardAccessRemoved,

			"ec_given": row.ECGiven,
			"status":   row.Status,

			"created_by":      row.CreatedBy,
			"created_by_name": row.CreatedByName,
			"created_at":      row.CreatedAt,

			"completed_by":      row.CompletedBy,
			"completed_by_name": row.CompletedName,
			"completed_at":      row.CompletedAt,

			"currently_assigned_devices": assignedDevices,
		},
	)
}

func (h *DashboardHandler) UpdateDeviceClearanceChecklist(c *gin.Context) {
	id, err := strconv.ParseInt(strings.TrimSpace(c.Param("id")), 10, 64)
	if err != nil || id <= 0 {
		response.BadRequest(c, "invalid lifecycle request id")
		return
	}

	var body lifecycleChecklist
	if err := c.ShouldBindJSON(&body); err != nil {
		response.BadRequest(c, "invalid checklist body")
		return
	}

	currentEmployee := strings.TrimSpace(c.GetString("employee_id"))
	if currentEmployee == "" {
		response.BadRequest(c, "authenticated employee ID is missing")
		return
	}

	var assignedTo, currentStatus, requestType string

	err = h.db.QueryRow(
		c.Request.Context(),
		`
		SELECT
			COALESCE(assigned_to,''),
			COALESCE(status,''),
			COALESCE(request_type,'Resignation')
		FROM public.device_clearances
		WHERE id=$1
		  AND deleted_at IS NULL
		`,
		id,
	).Scan(
		&assignedTo,
		&currentStatus,
		&requestType,
	)

	if err != nil {
		if err == pgx.ErrNoRows {
			response.NotFound(c, "lifecycle request not found")
			return
		}
		response.ServerError(c, err)
		return
	}

	if currentStatus == "Completed" {
		response.BadRequest(c, "completed lifecycle request cannot be edited")
		return
	}

	if assignedTo != currentEmployee {
		response.BadRequest(c, "only the assigned IT employee can update this task")
		return
	}

	status := lifecycleStatusFromChecklist(requestType, body)

	_, err = h.db.Exec(
		c.Request.Context(),
		`
		UPDATE public.device_clearances
		SET
			device_assigned=$1,
			vpn_access_enabled=$2,
			ip_phone_enabled=$3,
			printer_access_enabled=$4,
			endpoint_security_installed=$5,
			card_access_enabled=$6,

			device_returned=$7,
			vpn_removed=$8,
			ip_phone_disabled=$9,
			printer_access_removed=$10,
			panda_removed=$11,
			card_access_removed=$12,

			status=$13,
			updated_by=$14,
			updated_at=CURRENT_TIMESTAMP
		WHERE id=$15
		  AND deleted_at IS NULL
		`,
		body.DeviceAssigned,
		body.VPNAccessEnabled,
		body.IPPhoneEnabled,
		body.PrinterAccessEnabled,
		body.EndpointSecurityInstalled,
		body.CardAccessEnabled,

		body.DeviceReturned,
		body.VPNRemoved,
		body.IPPhoneDisabled,
		body.PrinterAccessRemoved,
		body.PandaRemoved,
		body.CardAccessRemoved,

		status,
		currentEmployee,
		id,
	)

	if err != nil {
		response.ServerError(c, err)
		return
	}

	response.OK(
		c,
		gin.H{
			"id":           id,
			"status":       status,
			"request_type": normalizeLifecycleType(requestType),
		},
	)
}

func (h *DashboardHandler) CompleteDeviceClearance(c *gin.Context) {
	ctx := c.Request.Context()

	id, err := strconv.ParseInt(strings.TrimSpace(c.Param("id")), 10, 64)
	if err != nil || id <= 0 {
		response.BadRequest(c, "invalid lifecycle request id")
		return
	}

	currentEmployee := strings.TrimSpace(c.GetString("employee_id"))
	if currentEmployee == "" {
		response.BadRequest(c, "authenticated employee ID is missing")
		return
	}

	tx, err := h.db.Begin(ctx)
	if err != nil {
		response.ServerError(c, err)
		return
	}
	defer func() { _ = tx.Rollback(ctx) }()

	var employeeID, assignedTo, status, requestType string
	var checklist lifecycleChecklist

	err = tx.QueryRow(
		ctx,
		`
		SELECT
			COALESCE(employee_id,''),
			COALESCE(assigned_to,''),
			COALESCE(status,''),
			COALESCE(request_type,'Resignation'),

			COALESCE(device_assigned,FALSE),
			COALESCE(vpn_access_enabled,FALSE),
			COALESCE(ip_phone_enabled,FALSE),
			COALESCE(printer_access_enabled,FALSE),
			COALESCE(endpoint_security_installed,FALSE),
			COALESCE(card_access_enabled,FALSE),

			COALESCE(device_returned,FALSE),
			COALESCE(vpn_removed,FALSE),
			COALESCE(ip_phone_disabled,FALSE),
			COALESCE(printer_access_removed,FALSE),
			COALESCE(panda_removed,FALSE),
			COALESCE(card_access_removed,FALSE)
		FROM public.device_clearances
		WHERE id=$1
		  AND deleted_at IS NULL
		FOR UPDATE
		`,
		id,
	).Scan(
		&employeeID,
		&assignedTo,
		&status,
		&requestType,

		&checklist.DeviceAssigned,
		&checklist.VPNAccessEnabled,
		&checklist.IPPhoneEnabled,
		&checklist.PrinterAccessEnabled,
		&checklist.EndpointSecurityInstalled,
		&checklist.CardAccessEnabled,

		&checklist.DeviceReturned,
		&checklist.VPNRemoved,
		&checklist.IPPhoneDisabled,
		&checklist.PrinterAccessRemoved,
		&checklist.PandaRemoved,
		&checklist.CardAccessRemoved,
	)

	if err != nil {
		if err == pgx.ErrNoRows {
			response.NotFound(c, "lifecycle request not found")
			return
		}
		response.ServerError(c, err)
		return
	}

	if status == "Completed" {
		response.BadRequest(c, "this lifecycle request is already completed")
		return
	}

	if assignedTo != currentEmployee {
		response.BadRequest(c, "only the assigned IT employee can complete this task")
		return
	}

	if !checklistComplete(requestType, checklist) {
		if isJoiningLifecycle(requestType) {
			response.BadRequest(c, "all six joining setup items must be completed first")
		} else {
			response.BadRequest(c, "all six exit clearance items must be completed first")
		}
		return
	}

	/*
		For exit requests, no device may remain assigned.
		This keeps it_equipment as the source of truth.
	*/
	if !isJoiningLifecycle(requestType) {
		var stillAssigned int

		if err := tx.QueryRow(
			ctx,
			`
			SELECT COUNT(*)::int
			FROM public.it_equipment
			WHERE BTRIM(COALESCE(emp_id,''))=$1
			  AND COALESCE(active,0)>0
			  AND (
					BTRIM(COALESCE(status,''))='1'
					OR LOWER(BTRIM(COALESCE(status,'')))='assigned'
			  )
			`,
			employeeID,
		).Scan(&stillAssigned); err != nil {
			response.ServerError(c, err)
			return
		}

		if stillAssigned > 0 {
			response.BadRequest(
				c,
				fmt.Sprintf(
					"%d device(s) are still assigned to this employee; return or transfer them before completing the exit task",
					stillAssigned,
				),
			)
			return
		}
	}

	completedByName := ""
	_ = tx.QueryRow(
		ctx,
		`
		SELECT BTRIM(COALESCE(employee_name,''))
		FROM public.employee_office_info
		WHERE BTRIM(COALESCE(employee_id,''))=$1
		LIMIT 1
		`,
		currentEmployee,
	).Scan(&completedByName)

	_, err = tx.Exec(
		ctx,
		`
		UPDATE public.device_clearances
		SET
			ec_given=TRUE,
			status='Completed',
			completed_by=$1,
			completed_by_name=NULLIF($2,''),
			completed_at=CURRENT_TIMESTAMP,
			updated_by=$1,
			updated_by_name=NULLIF($2,''),
			updated_at=CURRENT_TIMESTAMP
		WHERE id=$3
		  AND deleted_at IS NULL
		`,
		currentEmployee,
		completedByName,
		id,
	)

	if err != nil {
		response.ServerError(c, err)
		return
	}

	if err := tx.Commit(ctx); err != nil {
		response.ServerError(c, err)
		return
	}

	response.OK(
		c,
		gin.H{
			"id":                id,
			"status":            "Completed",
			"ec_given":          true,
			"request_type":      normalizeLifecycleType(requestType),
			"completed_by":      currentEmployee,
			"completed_by_name": completedByName,
		},
	)
}
