/* eslint-disable @next/next/no-img-element */
"use client";

import {
    useEffect,
    useMemo,
    useState,
} from "react";

import {
    ArrowLeft,
    CheckCircle2,
    Clock3,
    CreditCard,
    HardDrive,
    KeyRound,
    Laptop,
    Loader2,
    Network,
    Printer,
    ShieldCheck,
    UserRound,
} from "lucide-react";

import {
    useParams,
    useRouter,
} from "next/navigation";

import {
    Button,
} from "@/components/ui/button";

import {
    Checkbox,
} from "@/components/ui/checkbox";

import {
    api,
    deviceApi,
    type ApiOk,
    type Device,
} from "@/lib/api";

type LifecycleDetail = {
    id: number;
    reference_no: string;

    request_type: string;
    effective_date: string;

    employee_id: string;
    employee_name: string;
    designation: string;
    department: string;
    work_field: string;
    phone: string;
    email: string;
    employee_picture: string;

    assigned_to: string;
    assigned_to_name: string;
    remarks: string;

    device_assigned: boolean;
    vpn_access_enabled: boolean;
    ip_phone_enabled: boolean;
    printer_access_enabled: boolean;
    endpoint_security_installed: boolean;
    card_access_enabled: boolean;

    device_returned: boolean;
    vpn_removed: boolean;
    ip_phone_disabled: boolean;
    printer_access_removed: boolean;
    panda_removed: boolean;
    card_access_removed: boolean;

    status: string;
    ec_given: boolean;

    currently_assigned_devices: number;

    created_by: string;
    created_by_name: string;
    created_at: string;

    completed_by: string;
    completed_by_name: string;
    completed_at: string;
};

type LifecycleChecklist = {
    device_assigned: boolean;
    vpn_access_enabled: boolean;
    ip_phone_enabled: boolean;
    printer_access_enabled: boolean;
    endpoint_security_installed: boolean;
    card_access_enabled: boolean;

    device_returned: boolean;
    vpn_removed: boolean;
    ip_phone_disabled: boolean;
    printer_access_removed: boolean;
    panda_removed: boolean;
    card_access_removed: boolean;
};

const HRIS_EMPLOYEE_IMAGE_BASE_URL =
    "https://hris.fiberathome.net/hris/admin/";

function text(
    value:
        | string
        | null
        | undefined
): string {
    return String(
        value ?? ""
    ).trim();
}

function readApiData<T>(
    response: unknown
): T | undefined {
    if (
        response &&
        typeof response ===
            "object" &&
        "data" in response
    ) {
        const first =
            (
                response as {
                    data?: unknown;
                }
            ).data;

        if (
            first &&
            typeof first ===
                "object" &&
            "data" in first
        ) {
            return (
                first as {
                    data?: T;
                }
            ).data;
        }

        return first as T;
    }

    return response as T;
}

function resolvePicture(
    picture: string
): string {
    const value =
        text(
            picture
        );

    if (!value) {
        return "";
    }

    if (
        value.startsWith(
            "http://"
        ) ||
        value.startsWith(
            "https://"
        )
    ) {
        return value;
    }

    return (
        HRIS_EMPLOYEE_IMAGE_BASE_URL +
        value.replace(
            /^\/+/,
            ""
        )
    );
}

function formatDate(
    value:
        | string
        | null
        | undefined
): string {
    const raw =
        text(
            value
        );

    if (!raw) {
        return "—";
    }

    const date =
        new Date(
            raw
        );

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {
        return raw;
    }

    return date.toLocaleDateString(
        "en-GB",
        {
            day:
                "2-digit",

            month:
                "short",

            year:
                "numeric",
        }
    );
}

const EMPTY_CHECKLIST: LifecycleChecklist = {
    device_assigned:
        false,

    vpn_access_enabled:
        false,

    ip_phone_enabled:
        false,

    printer_access_enabled:
        false,

    endpoint_security_installed:
        false,

    card_access_enabled:
        false,

    device_returned:
        false,

    vpn_removed:
        false,

    ip_phone_disabled:
        false,

    printer_access_removed:
        false,

    panda_removed:
        false,

    card_access_removed:
        false,
};

export default function LifecycleTaskPage() {
    const params =
        useParams<{
            id: string;
        }>();

    const router =
        useRouter();

    const id =
        Number(
            params.id
        );

    const [
        detail,
        setDetail,
    ] =
        useState<
            LifecycleDetail | null
        >(
            null
        );

    const [
        checklist,
        setChecklist,
    ] =
        useState<LifecycleChecklist>(
            EMPTY_CHECKLIST
        );

    const [
        devices,
        setDevices,
    ] =
        useState<
            Device[]
        >(
            []
        );

    const [
        loading,
        setLoading,
    ] =
        useState(
            true
        );

    const [
        saving,
        setSaving,
    ] =
        useState(
            false
        );

    const [
        completing,
        setCompleting,
    ] =
        useState(
            false
        );

    const [
        error,
        setError,
    ] =
        useState(
            ""
        );

    const load =
        async () => {
            if (
                !Number.isFinite(
                    id
                ) ||
                id <=
                    0
            ) {
                setError(
                    "Invalid lifecycle request ID."
                );

                setLoading(
                    false
                );

                return;
            }

            try {
                setLoading(
                    true
                );

                setError(
                    ""
                );

                const response =
                    await api.get<
                        ApiOk<
                            LifecycleDetail
                        >
                    >(
                        `/device-clearances/${id}`
                    );

                const item =
                    readApiData<
                        LifecycleDetail
                    >(
                        response
                    );

                if (!item) {
                    throw new Error(
                        "Lifecycle request not found."
                    );
                }

                setDetail(
                    item
                );

                setChecklist({
                    device_assigned:
                        item.device_assigned,

                    vpn_access_enabled:
                        item.vpn_access_enabled,

                    ip_phone_enabled:
                        item.ip_phone_enabled,

                    printer_access_enabled:
                        item.printer_access_enabled,

                    endpoint_security_installed:
                        item.endpoint_security_installed,

                    card_access_enabled:
                        item.card_access_enabled,

                    device_returned:
                        item.device_returned,

                    vpn_removed:
                        item.vpn_removed,

                    ip_phone_disabled:
                        item.ip_phone_disabled,

                    printer_access_removed:
                        item.printer_access_removed,

                    panda_removed:
                        item.panda_removed,

                    card_access_removed:
                        item.card_access_removed,
                });

                try {
                    const deviceResponse =
                        await deviceApi
                            .byEmployee(
                                item.employee_id
                            );

                    setDevices(
                        readApiData<
                            Device[]
                        >(
                            deviceResponse
                        ) ?? []
                    );
                } catch {
                    setDevices(
                        []
                    );
                }
            } catch (
                reason
            ) {
                setError(
                    reason instanceof
                        Error
                        ? reason.message
                        : "Unable to load lifecycle request."
                );
            } finally {
                setLoading(
                    false
                );
            }
        };

    useEffect(
        () => {
            void load();
        },
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [
            id,
        ]
    );

    const isJoining =
        detail?.request_type ===
        "Joining";

    const activeItems =
        useMemo(
            () => {
                if (
                    isJoining
                ) {
                    return [
                        {
                            key:
                                "device_assigned" as const,

                            label:
                                "Device Assigned",

                            description:
                                "Assign and configure the required IT equipment for the employee.",

                            icon:
                                <Laptop className="h-4 w-4" />,
                        },
                        {
                            key:
                                "vpn_access_enabled" as const,

                            label:
                                "VPN Access Enabled",

                            description:
                                "Create or enable VPN access when required by the employee's role.",

                            icon:
                                <KeyRound className="h-4 w-4" />,
                        },
                        {
                            key:
                                "ip_phone_enabled" as const,

                            label:
                                "IP Phone Enabled",

                            description:
                                "Create or activate the employee IP phone extension.",

                            icon:
                                <Network className="h-4 w-4" />,
                        },
                        {
                            key:
                                "printer_access_enabled" as const,

                            label:
                                "Printer Access Enabled",

                            description:
                                "Grant approved printer / print-server access.",

                            icon:
                                <Printer className="h-4 w-4" />,
                        },
                        {
                            key:
                                "endpoint_security_installed" as const,

                            label:
                                "Endpoint Security Installed",

                            description:
                                "Install and activate Panda / endpoint security on the employee device.",

                            icon:
                                <ShieldCheck className="h-4 w-4" />,
                        },
                        {
                            key:
                                "card_access_enabled" as const,

                            label:
                                "Card Access Enabled",

                            description:
                                "Activate the employee physical access card.",

                            icon:
                                <CreditCard className="h-4 w-4" />,
                        },
                    ];
                }

                return [
                    {
                        key:
                            "device_returned" as const,

                        label:
                            "Device Returned",

                        description:
                            "Confirm the employee has returned all assigned IT equipment.",

                        icon:
                            <HardDrive className="h-4 w-4" />,
                    },
                    {
                        key:
                            "vpn_removed" as const,

                        label:
                            "VPN Access Removed",

                        description:
                            "VPN profile/account access has been revoked.",

                        icon:
                            <KeyRound className="h-4 w-4" />,
                    },
                    {
                        key:
                            "ip_phone_disabled" as const,

                        label:
                            "IP Phone Disabled",

                        description:
                            "IP phone extension or voice service has been disabled.",

                        icon:
                            <Network className="h-4 w-4" />,
                    },
                    {
                        key:
                            "printer_access_removed" as const,

                        label:
                            "Printer Access Removed",

                        description:
                            "Printer / print-server access has been revoked.",

                        icon:
                            <Printer className="h-4 w-4" />,
                    },
                    {
                        key:
                            "panda_removed" as const,

                        label:
                            "Endpoint Security Removed",

                        description:
                            "Panda / endpoint-security profile has been removed where applicable.",

                        icon:
                            <ShieldCheck className="h-4 w-4" />,
                    },
                    {
                        key:
                            "card_access_removed" as const,

                        label:
                            "Card Access Disabled",

                        description:
                            "Employee physical access card has been deactivated.",

                        icon:
                            <CreditCard className="h-4 w-4" />,
                    },
                ];
            },
            [
                isJoining,
            ]
        );

    const completed =
        activeItems.filter(
            (
                item
            ) =>
                checklist[
                    item.key
                ]
        ).length;

    const allDone =
        completed ===
        activeItems.length;

    const readOnly =
        detail?.status ===
        "Completed";

    async function save() {
        try {
            setSaving(
                true
            );

            setError(
                ""
            );

            await api.patch(
                `/device-clearances/${id}/checklist`,
                checklist
            );

            await load();
        } catch (
            reason
        ) {
            setError(
                reason instanceof
                    Error
                    ? reason.message
                    : "Unable to save progress."
            );
        } finally {
            setSaving(
                false
            );
        }
    }

    async function complete() {
        try {
            setCompleting(
                true
            );

            setError(
                ""
            );

            await api.patch(
                `/device-clearances/${id}/complete`,
                {}
            );

            await load();
        } catch (
            reason
        ) {
            setError(
                reason instanceof
                    Error
                    ? reason.message
                    : "Unable to complete lifecycle task."
            );
        } finally {
            setCompleting(
                false
            );
        }
    }

    if (
        loading
    ) {
        return (
            <div className="flex min-h-[360px] items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
        );
    }

    if (
        !detail
    ) {
        return (
            <div className="p-6">
                <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
                    {error ||
                        "Lifecycle request not found."}
                </div>
            </div>
        );
    }

    const picture =
        resolvePicture(
            detail.employee_picture
        );

    const dateLabel =
        isJoining
            ? "Joining Date"
            : "Last Working Date";

    return (
        <div className="w-full p-4 sm:p-6">
            <div className="mx-auto max-w-[1400px] space-y-5">
                {/* HEADER */}

                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-3">
                        <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            onClick={() =>
                                router.back()
                            }
                        >
                            <ArrowLeft className="h-4 w-4" />
                        </Button>

                        <div>
                            <div className="flex flex-wrap items-center gap-2">
                                <h1 className="text-xl font-semibold text-foreground">
                                    {isJoining
                                        ? "Employee Joining IT Setup"
                                        : "Employee IT Exit Clearance"}
                                </h1>

                                <span
                                    className={`
                                        rounded-full
                                        border
                                        px-2.5
                                        py-1
                                        text-[11px]
                                        font-semibold
                                        ${
                                            isJoining
                                                ? "border-blue-200 bg-blue-50 text-blue-700"
                                                : "border-amber-200 bg-amber-50 text-amber-700"
                                        }
                                    `}
                                >
                                    {detail.request_type}
                                </span>
                            </div>

                            <p className="mt-1 text-sm text-muted-foreground">
                                {detail.reference_no}
                            </p>
                        </div>
                    </div>

                    <StatusBadge
                        status={
                            detail.status
                        }
                    />
                </div>

                {error && (
                    <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                        {error}
                    </div>
                )}

                {/* EMPLOYEE + ASSIGNMENT */}

                <section className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                    <div className="flex flex-col gap-5 xl:flex-row">
                        <div className="flex min-w-[260px] items-center gap-4">
                            <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-full border border-border bg-muted">
                                {picture ? (
                                    <img
                                        src={
                                            picture
                                        }
                                        alt={
                                            detail.employee_name
                                        }
                                        className="h-full w-full object-cover"
                                    />
                                ) : (
                                    <UserRound className="h-8 w-8 text-muted-foreground" />
                                )}
                            </div>

                            <div>
                                <p className="font-semibold text-foreground">
                                    {detail.employee_name}
                                </p>

                                <p className="mt-0.5 text-xs font-semibold text-primary">
                                    {detail.employee_id}
                                </p>

                                <p className="mt-1 text-xs text-muted-foreground">
                                    {detail.designation ||
                                        "—"}
                                </p>
                            </div>
                        </div>

                        <div className="grid flex-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                            <Info
                                label="Department"
                                value={
                                    detail.department
                                }
                            />

                            <Info
                                label={
                                    dateLabel
                                }
                                value={
                                    formatDate(
                                        detail.effective_date
                                    )
                                }
                            />

                            <Info
                                label="Responsible IT"
                                value={`${detail.assigned_to_name} (${detail.assigned_to})`}
                            />

                            <Info
                                label="Assigned Devices"
                                value={String(
                                    detail.currently_assigned_devices
                                )}
                            />
                        </div>
                    </div>
                </section>

                {/* DEVICE CONTEXT */}

                <section className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
                    <div className="flex items-center justify-between gap-3 border-b border-border px-5 py-4">
                        <div>
                            <h2 className="text-sm font-semibold text-foreground">
                                Device Context
                            </h2>

                            <p className="mt-1 text-xs text-muted-foreground">
                                {isJoining
                                    ? "Devices assigned to the employee will appear here as provisioning is completed."
                                    : "All assigned devices must be returned or transferred before exit completion."}
                            </p>
                        </div>

                        <span className="rounded-full border border-primary/15 bg-primary/5 px-2.5 py-1 text-[11px] font-semibold text-primary">
                            {devices.length}{" "}
                            {devices.length ===
                            1
                                ? "device"
                                : "devices"}
                        </span>
                    </div>

                    <div className="p-5">
                        {devices.length ===
                        0 ? (
                            <div className="flex min-h-[100px] items-center justify-center rounded-xl border border-dashed border-border bg-muted/15 text-sm text-muted-foreground">
                                No device record currently linked to this employee.
                            </div>
                        ) : (
                            <div className="overflow-x-auto rounded-xl border border-border">
                                <table className="w-full min-w-[760px]">
                                    <thead className="bg-muted/35">
                                        <tr>
                                            <Head>
                                                Device
                                            </Head>

                                            <Head>
                                                Brand / Model
                                            </Head>

                                            <Head>
                                                Serial
                                            </Head>

                                            <Head>
                                                Status
                                            </Head>
                                        </tr>
                                    </thead>

                                    <tbody className="divide-y divide-border">
                                        {devices.map(
                                            (
                                                device
                                            ) => (
                                                <tr
                                                    key={
                                                        device.id
                                                    }
                                                >
                                                    <td className="px-4 py-3 text-sm font-medium">
                                                        {text(
                                                            device.category
                                                        ) ||
                                                            "Device"}
                                                    </td>

                                                    <td className="px-4 py-3 text-sm">
                                                        {text(
                                                            device.brand
                                                        ) ||
                                                            "—"}{" "}
                                                        {text(
                                                            device.model_no
                                                        )}
                                                    </td>

                                                    <td className="px-4 py-3 font-mono text-xs">
                                                        {text(
                                                            device.device_serial
                                                        ) ||
                                                            "—"}
                                                    </td>

                                                    <td className="px-4 py-3 text-xs">
                                                        {text(
                                                            device.status
                                                        ) ||
                                                            "—"}
                                                    </td>
                                                </tr>
                                            )
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </section>

                {/* CHECKLIST */}

                <section className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
                    <div className="flex flex-col gap-2 border-b border-border px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h2 className="text-sm font-semibold text-foreground">
                                {isJoining
                                    ? "Joining IT Checklist"
                                    : "Exit IT Checklist"}
                            </h2>

                            <p className="mt-1 text-xs text-muted-foreground">
                                Complete all six activities before closing this task.
                            </p>
                        </div>

                        <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-muted-foreground">
                                {completed}/
                                {activeItems.length}
                            </span>

                            <div className="h-2 w-28 overflow-hidden rounded-full bg-muted">
                                <div
                                    className="h-full rounded-full bg-primary transition-all"
                                    style={{
                                        width: `${
                                            (completed /
                                                activeItems.length) *
                                            100
                                        }%`,
                                    }}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="grid gap-3 p-5 md:grid-cols-2">
                        {activeItems.map(
                            (
                                item
                            ) => (
                                <ChecklistCard
                                    key={
                                        item.key
                                    }
                                    icon={
                                        item.icon
                                    }
                                    label={
                                        item.label
                                    }
                                    description={
                                        item.description
                                    }
                                    checked={
                                        checklist[
                                            item.key
                                        ]
                                    }
                                    disabled={
                                        readOnly
                                    }
                                    onChange={(
                                        value
                                    ) =>
                                        setChecklist(
                                            (
                                                previous
                                            ) => ({
                                                ...previous,

                                                [item.key]:
                                                    value,
                                            })
                                        )
                                    }
                                />
                            )
                        )}
                    </div>
                </section>

                {/* REMARKS */}

                {detail.remarks && (
                    <section className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                            Notes
                        </p>

                        <p className="mt-2 whitespace-pre-wrap text-sm text-foreground">
                            {detail.remarks}
                        </p>
                    </section>
                )}

                {/* ACTIONS */}

                {!readOnly && (
                    <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
                        <Button
                            type="button"
                            variant="outline"
                            disabled={
                                saving ||
                                completing
                            }
                            onClick={() =>
                                void save()
                            }
                        >
                            {saving ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Saving...
                                </>
                            ) : (
                                "Save Progress"
                            )}
                        </Button>

                        <Button
                            type="button"
                            disabled={
                                !allDone ||
                                saving ||
                                completing
                            }
                            onClick={() =>
                                void complete()
                            }
                        >
                            {completing ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Completing...
                                </>
                            ) : (
                                <>
                                    <CheckCircle2 className="mr-2 h-4 w-4" />
                                    Complete Task
                                </>
                            )}
                        </Button>
                    </div>
                )}

                {readOnly && (
                    <div className="flex items-center justify-end gap-2 text-sm font-medium text-emerald-700">
                        <CheckCircle2 className="h-4 w-4" />
                        Task completed by{" "}
                        {detail.completed_by_name ||
                            detail.completed_by}
                    </div>
                )}
            </div>
        </div>
    );
}

function ChecklistCard({
    icon,
    label,
    description,
    checked,
    disabled,
    onChange,
}: {
    icon:
        React.ReactNode;

    label:
        string;

    description:
        string;

    checked:
        boolean;

    disabled:
        boolean;

    onChange:
        (
            value: boolean
        ) => void;
}) {
    return (
        <label
            className={`
                flex
                cursor-pointer
                items-start
                gap-3
                rounded-xl
                border
                p-4
                transition
                ${
                    checked
                        ? "border-emerald-200 bg-emerald-50/60"
                        : "border-border bg-background hover:bg-muted/20"
                }
                ${
                    disabled
                        ? "cursor-default opacity-75"
                        : ""
                }
            `}
        >
            <div
                className={`
                    flex
                    h-9
                    w-9
                    shrink-0
                    items-center
                    justify-center
                    rounded-lg
                    ${
                        checked
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-primary/10 text-primary"
                    }
                `}
            >
                {icon}
            </div>

            <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-foreground">
                    {label}
                </p>

                <p className="mt-1 text-xs leading-5 text-muted-foreground">
                    {description}
                </p>
            </div>

            <Checkbox
                checked={
                    checked
                }
                disabled={
                    disabled
                }
                onCheckedChange={(
                    value
                ) =>
                    onChange(
                        value ===
                            true
                    )
                }
                className="mt-1"
            />
        </label>
    );
}

function StatusBadge({
    status,
}: {
    status:
        string;
}) {
    const value =
        text(
            status
        );

    const completed =
        value ===
        "Completed";

    const progress =
        value ===
        "In Process";

    return (
        <span
            className={`
                inline-flex
                items-center
                gap-1.5
                rounded-full
                border
                px-3
                py-1.5
                text-xs
                font-semibold
                ${
                    completed
                        ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                        : progress
                        ? "border-blue-200 bg-blue-50 text-blue-700"
                        : "border-amber-200 bg-amber-50 text-amber-700"
                }
            `}
        >
            {completed ? (
                <CheckCircle2 className="h-3.5 w-3.5" />
            ) : (
                <Clock3 className="h-3.5 w-3.5" />
            )}

            {value ||
                "Pending Clearance"}
        </span>
    );
}

function Info({
    label,
    value,
}: {
    label:
        string;

    value:
        string;
}) {
    return (
        <div>
            <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                {label}
            </p>

            <p className="mt-1 text-sm font-medium text-foreground">
                {value ||
                    "—"}
            </p>
        </div>
    );
}

function Head({
    children,
}: {
    children:
        React.ReactNode;
}) {
    return (
        <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            {children}
        </th>
    );
}
