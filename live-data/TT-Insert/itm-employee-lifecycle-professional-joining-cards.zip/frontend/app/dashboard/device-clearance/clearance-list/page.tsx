"use client";

import {
    useCallback,
    useEffect,
    useState,
} from "react";

import {
    CheckCircle2,
    ChevronRight,
    Clock3,
    Loader2,
    Plus,
    RefreshCw,
    Search,
    UserPlus,
} from "lucide-react";

import {
    useRouter,
} from "next/navigation";

import {
    Button,
} from "@/components/ui/button";

import {
    Input,
} from "@/components/ui/input";

import {
    api,
    type ApiOk,
} from "@/lib/api";

type Item = {
    id: number;
    reference_no: string;

    request_type: string;
    effective_date: string;

    employee_id: string;
    employee_name: string;
    designation: string;
    department: string;

    assigned_to: string;
    assigned_to_name: string;

    status: string;
    created_at: string;
};

function readApiData<T>(
    response: unknown
): T | undefined {
    if (
        response &&
        typeof response ===
            "object" &&
        "data" in response
    ) {
        const first =
            (
                response as {
                    data?: unknown;
                }
            ).data;

        if (
            first &&
            typeof first ===
                "object" &&
            "data" in first
        ) {
            return (
                first as {
                    data?: T;
                }
            ).data;
        }

        return first as T;
    }

    return response as T;
}

function formatDate(
    value: string
): string {
    if (!value) {
        return "—";
    }

    const date =
        new Date(
            value
        );

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {
        return value;
    }

    return date.toLocaleDateString(
        "en-GB",
        {
            day:
                "2-digit",

            month:
                "short",

            year:
                "numeric",
        }
    );
}

export default function LifecycleListPage() {
    const router =
        useRouter();

    const [
        items,
        setItems,
    ] =
        useState<
            Item[]
        >(
            []
        );

    const [
        loading,
        setLoading,
    ] =
        useState(
            true
        );

    const [
        error,
        setError,
    ] =
        useState(
            ""
        );

    const [
        search,
        setSearch,
    ] =
        useState(
            ""
        );

    const [
        status,
        setStatus,
    ] =
        useState(
            ""
        );

    const [
        type,
        setType,
    ] =
        useState(
            ""
        );

    const load =
        useCallback(
            async () => {
                try {
                    setLoading(
                        true
                    );

                    setError(
                        ""
                    );

                    const query =
                        new URLSearchParams();

                    if (
                        search.trim()
                    ) {
                        query.set(
                            "search",
                            search.trim()
                        );
                    }

                    if (
                        status
                    ) {
                        query.set(
                            "status",
                            status
                        );
                    }

                    if (
                        type
                    ) {
                        query.set(
                            "request_type",
                            type
                        );
                    }

                    const suffix =
                        query.toString();

                    const response =
                        await api.get<
                            ApiOk<
                                Item[]
                            >
                        >(
                            `/device-clearances${
                                suffix
                                    ? `?${suffix}`
                                    : ""
                            }`
                        );

                    setItems(
                        readApiData<
                            Item[]
                        >(
                            response
                        ) ?? []
                    );
                } catch (
                    reason
                ) {
                    setItems(
                        []
                    );

                    setError(
                        reason instanceof
                            Error
                            ? reason.message
                            : "Unable to load lifecycle requests."
                    );
                } finally {
                    setLoading(
                        false
                    );
                }
            },
            [
                search,
                status,
                type,
            ]
        );

    useEffect(
        () => {
            const timer =
                window.setTimeout(
                    () => {
                        void load();
                    },
                    250
                );

            return () =>
                window.clearTimeout(
                    timer
                );
        },
        [
            load,
        ]
    );

    return (
        <div className="w-full p-4 sm:p-6">
            <div className="mx-auto max-w-[1600px] space-y-5">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h1 className="text-xl font-semibold text-foreground">
                            Employee IT Lifecycle
                        </h1>

                        <p className="mt-1 text-sm text-muted-foreground">
                            Joining and exit tasks assigned to IT personnel.
                        </p>
                    </div>

                    <Button
                        type="button"
                        onClick={() =>
                            router.push(
                                "/dashboard/device-clearance/clearance-form"
                            )
                        }
                    >
                        <Plus className="mr-2 h-4 w-4" />
                        New Lifecycle Task
                    </Button>
                </div>

                <section className="rounded-2xl border border-border bg-card p-4 shadow-sm">
                    <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_190px_190px_auto]">
                        <div className="relative">
                            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />

                            <Input
                                value={
                                    search
                                }
                                onChange={(
                                    event
                                ) =>
                                    setSearch(
                                        event
                                            .target
                                            .value
                                    )
                                }
                                placeholder="Search employee, ID or reference..."
                                className="h-10 pl-9"
                            />
                        </div>

                        <select
                            value={
                                type
                            }
                            onChange={(
                                event
                            ) =>
                                setType(
                                    event
                                        .target
                                        .value
                                )
                            }
                            className="h-10 rounded-md border border-input bg-background px-3 text-sm"
                        >
                            <option value="">
                                All Events
                            </option>

                            <option value="Joining">
                                Joining
                            </option>

                            <option value="Resignation">
                                Resignation
                            </option>

                            <option value="Retirement">
                                Retirement
                            </option>

                            <option value="Contract End">
                                Contract End
                            </option>

                            <option value="Termination">
                                Termination
                            </option>

                            <option value="Other">
                                Other
                            </option>
                        </select>

                        <select
                            value={
                                status
                            }
                            onChange={(
                                event
                            ) =>
                                setStatus(
                                    event
                                        .target
                                        .value
                                )
                            }
                            className="h-10 rounded-md border border-input bg-background px-3 text-sm"
                        >
                            <option value="">
                                All Status
                            </option>

                            <option value="Pending Clearance">
                                Pending
                            </option>

                            <option value="In Process">
                                In Process
                            </option>

                            <option value="Completed">
                                Completed
                            </option>
                        </select>

                        <Button
                            type="button"
                            variant="outline"
                            disabled={
                                loading
                            }
                            onClick={() =>
                                void load()
                            }
                        >
                            <RefreshCw
                                className={`mr-2 h-4 w-4 ${
                                    loading
                                        ? "animate-spin"
                                        : ""
                                }`}
                            />
                            Refresh
                        </Button>
                    </div>
                </section>

                {error && (
                    <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                        {error}
                    </div>
                )}

                <section className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
                    {loading ? (
                        <div className="flex min-h-[280px] items-center justify-center gap-2 text-sm text-muted-foreground">
                            <Loader2 className="h-5 w-5 animate-spin text-primary" />
                            Loading lifecycle tasks...
                        </div>
                    ) : items.length ===
                      0 ? (
                        <div className="flex min-h-[280px] flex-col items-center justify-center text-center">
                            <UserPlus className="h-9 w-9 text-muted-foreground/40" />

                            <p className="mt-3 text-sm font-semibold text-foreground">
                                No lifecycle tasks found
                            </p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full min-w-[1100px]">
                                <thead className="bg-muted/35">
                                    <tr>
                                        <Head>
                                            Reference
                                        </Head>

                                        <Head>
                                            Event
                                        </Head>

                                        <Head>
                                            Employee
                                        </Head>

                                        <Head>
                                            Department
                                        </Head>

                                        <Head>
                                            Effective Date
                                        </Head>

                                        <Head>
                                            Responsible IT
                                        </Head>

                                        <Head>
                                            Status
                                        </Head>

                                        <Head>
                                            Action
                                        </Head>
                                    </tr>
                                </thead>

                                <tbody className="divide-y divide-border">
                                    {items.map(
                                        (
                                            item
                                        ) => (
                                            <tr
                                                key={
                                                    item.id
                                                }
                                                className="cursor-pointer hover:bg-muted/20"
                                                onClick={() =>
                                                    router.push(
                                                        `/dashboard/device-clearance/approval/${item.id}`
                                                    )
                                                }
                                            >
                                                <Cell>
                                                    <span className="font-mono text-xs font-semibold text-primary">
                                                        {item.reference_no}
                                                    </span>
                                                </Cell>

                                                <Cell>
                                                    <EventBadge
                                                        value={
                                                            item.request_type
                                                        }
                                                    />
                                                </Cell>

                                                <Cell>
                                                    <p className="font-semibold text-foreground">
                                                        {item.employee_name}
                                                    </p>

                                                    <p className="mt-0.5 text-xs text-muted-foreground">
                                                        {item.employee_id}
                                                    </p>
                                                </Cell>

                                                <Cell>
                                                    <p className="text-sm">
                                                        {item.department ||
                                                            "—"}
                                                    </p>

                                                    <p className="mt-0.5 text-xs text-muted-foreground">
                                                        {item.designation}
                                                    </p>
                                                </Cell>

                                                <Cell>
                                                    {formatDate(
                                                        item.effective_date
                                                    )}
                                                </Cell>

                                                <Cell>
                                                    <p className="text-sm font-medium">
                                                        {item.assigned_to_name ||
                                                            "—"}
                                                    </p>

                                                    <p className="mt-0.5 text-xs text-muted-foreground">
                                                        {item.assigned_to}
                                                    </p>
                                                </Cell>

                                                <Cell>
                                                    <StatusBadge
                                                        status={
                                                            item.status
                                                        }
                                                    />
                                                </Cell>

                                                <Cell>
                                                    <Button
                                                        type="button"
                                                        size="icon"
                                                        variant="ghost"
                                                        onClick={(
                                                            event
                                                        ) => {
                                                            event.stopPropagation();

                                                            router.push(
                                                                `/dashboard/device-clearance/approval/${item.id}`
                                                            );
                                                        }}
                                                    >
                                                        <ChevronRight className="h-4 w-4" />
                                                    </Button>
                                                </Cell>
                                            </tr>
                                        )
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </section>
            </div>
        </div>
    );
}

function EventBadge({
    value,
}: {
    value:
        string;
}) {
    const joining =
        value ===
        "Joining";

    return (
        <span
            className={`
                rounded-full
                border
                px-2.5
                py-1
                text-[11px]
                font-semibold
                ${
                    joining
                        ? "border-blue-200 bg-blue-50 text-blue-700"
                        : "border-amber-200 bg-amber-50 text-amber-700"
                }
            `}
        >
            {value}
        </span>
    );
}

function StatusBadge({
    status,
}: {
    status:
        string;
}) {
    const complete =
        status ===
        "Completed";

    const progress =
        status ===
        "In Process";

    return (
        <span
            className={`
                inline-flex
                items-center
                gap-1.5
                rounded-full
                border
                px-2.5
                py-1
                text-[11px]
                font-semibold
                ${
                    complete
                        ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                        : progress
                        ? "border-blue-200 bg-blue-50 text-blue-700"
                        : "border-amber-200 bg-amber-50 text-amber-700"
                }
            `}
        >
            {complete ? (
                <CheckCircle2 className="h-3.5 w-3.5" />
            ) : (
                <Clock3 className="h-3.5 w-3.5" />
            )}

            {status ||
                "Pending Clearance"}
        </span>
    );
}

function Head({
    children,
}: {
    children:
        React.ReactNode;
}) {
    return (
        <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            {children}
        </th>
    );
}

function Cell({
    children,
}: {
    children:
        React.ReactNode;
}) {
    return (
        <td className="px-4 py-3 align-middle text-sm">
            {children}
        </td>
    );
}
