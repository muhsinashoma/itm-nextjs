ITM DEVICE CLEARANCE - EMPLOYEE IMAGE FIX
=========================================

WHY THE IMAGE WAS NOT SHOWING
-----------------------------

Your PostgreSQL personal-information CSV stores the employee picture as a
RELATIVE HRIS path, for example:

  02-302 | Md. Shahed Alam | user_images/1410071435.jpg
  02-0130 | Khalid Pervez | user_images/1438596179.jpg
  02-0073 | Md. Arafat Nazmul | user_images/1673251282.jpg
  02-0198 | Ismat Zerin | user_images/1397107689.jpg
  02-0265 | Abu Musa Mosarrof | user_images/1338113584.jpg

The previous PHP code did not use that value by itself.

It created:

    https://hris.fiberathome.net/hris/admin/ + picture

For example:

    picture:
        user_images/1401616150.jpg

becomes:

    https://hris.fiberathome.net/hris/admin/user_images/1401616150.jpg


LOCALHOST IS NOT THE PROBLEM
----------------------------

The ITM frontend may run on:

    http://localhost:5173

and an <img> element may still render an HTTPS image hosted on:

    https://hris.fiberathome.net

CORS is not required just to DISPLAY a normal cross-origin <img>.

Therefore this package DOES NOT require a local photo folder and DOES NOT
require the Next.js image proxy for the normal HRIS image URL.


FILES INCLUDED
--------------

itm/
└── backend/
    └── internal/
        └── handler/
            └── handlers.go

frontend/
└── app/
    └── dashboard/
        └── device-clearance/
            ├── clearance-form/
            │   └── page.tsx
            └── create/
                └── page.tsx

database/
└── check_employee_picture.sql


BACKEND FIX
-----------

/employees/search now LEFT JOINs:

    employee_office_info o
    employee_personal_info p

and returns:

    employee_id
    employee_name
    designation
    department
    work_field
    sub_function
    active
    personal_cell
    official_cell
    email
    official_email
    picture

The previous active Search implementation only selected office fields, so the
React autocomplete had no picture value to render.

The IT personnel endpoint also returns picture.


FRONTEND FIX
------------

resolvePicture() now reproduces the legacy PHP logic:

    const HRIS_EMPLOYEE_IMAGE_BASE_URL =
        "https://hris.fiberathome.net/hris/admin/";

    return `${HRIS_EMPLOYEE_IMAGE_BASE_URL}${cleanPicturePath}`;

The employee search result, selected employee profile, and assigned IT-person
dropdown all use EmployeeAvatar(), so all three now receive the correct full
HRIS image URL.


INSTALL
-------

Copy the folders to your ITM project, or run:

    chmod +x install.sh
    ./install.sh /path/to/your/ITM-project

Then restart:

    Go backend
    frontend dev server

No .env change is required for this HRIS image path.


IMPORTANT ACTIVE ROUTE
----------------------

Your screenshot is:

    /dashboard/device-clearance/clearance-form

Therefore the important file is:

    frontend/app/dashboard/device-clearance/clearance-form/page.tsx

A duplicate copy is also included under /create because your supplied source
file comment referred to create/page.tsx.
