/* eslint-disable @next/next/no-img-element */
//frontend/app/dashboard/device-clearance/create/page.tsx
"use client";

import {
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";

import { useRouter } from "next/navigation";

import {
    CalendarDays,
    CheckCircle2,
    ChevronDown,
    HardDrive,
    Loader2,
    PackageOpen,
    Search,
    UserRound,
    X,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";

import {
    api,
    dashboardApi,
    deviceApi,
    type ApiOk,
    type Device,
} from "@/lib/api";

/* ============================================================
   TYPES
============================================================ */

type EmployeeSearchRaw = {
    employee_id?: string;
    employee_name?: string;
    designation?: string | null;
    department?: string | null;
    department_name?: string | null;
    work_field?: string | null;
    personal_cell?: string | null;
    official_cell?: string | null;
    email?: string | null;
    official_email?: string | null;
    picture?: string | null;
    active?: string | null;

    // Legacy Go response support.
    EmpID?: string;
    Name?: string;
    Desig?: string | null;
    Dept?: string | null;
};

type EmployeeOption = {
    employee_id: string;
    employee_name: string;
    designation: string;
    department: string;
    work_field: string;
    phone: string;
    email: string;
    picture: string;
};

type ITEmployeeRaw = {
    employee_id: string;
    employee_name: string;
    designation?: string | null;
    department?: string | null;
    picture?: string | null;
};

type ITEmployeeOption = {
    employee_id: string;
    employee_name: string;
    designation: string;
    department: string;
    picture: string;
};

type EmployeeDetailsRaw = {
    employee_id?: string;
    employee_name?: string;
    designation?: string | null;
    department?: string | null;
    department_name?: string | null;
    work_field?: string | null;
    personal_cell?: string | null;
    official_cell?: string | null;
    email?: string | null;
    official_email?: string | null;
    picture?: string | null;
};

type CreateClearanceResult = {
    id: number;
    reference_no?: string;
    status?: string;
};

type ClearanceFormState = {
    employee_id: string;
    employee_name: string;
    designation: string;
    department: string;
    work_field: string;
    phone: string;
    email: string;
    employee_picture: string;
    resignation_date: string;
    separation_mode: string;
    assigned_to: string;
    assigned_to_name: string;
    remarks: string;
};

type ClearanceChecklistState = {
    device_returned: boolean;
    vpn_removed: boolean;
    ip_phone_disabled: boolean;
    printer_access_removed: boolean;
    panda_removed: boolean;
};

/* ============================================================
   CONSTANTS
============================================================ */

const EMPTY_FORM: ClearanceFormState = {
    employee_id: "",
    employee_name: "",
    designation: "",
    department: "",
    work_field: "",
    phone: "",
    email: "",
    employee_picture: "",
    resignation_date: "",
    separation_mode: "Resignation",
    assigned_to: "",
    assigned_to_name: "",
    remarks: "",
};

const EMPTY_CHECKLIST: ClearanceChecklistState = {
    device_returned: false,
    vpn_removed: false,
    ip_phone_disabled: false,
    printer_access_removed: false,
    panda_removed: false,
};

/*
 * Legacy ITM / HRIS employee image location.
 *
 * PostgreSQL employee_personal_info.picture contains values like:
 *
 *     user_images/1401616150.jpg
 *
 * The old PHP implementation rendered:
 *
 *     https://hris.fiberathome.net/hris/admin/<picture>
 *
 * A normal <img> tag may load this HTTPS URL directly even while
 * the ITM frontend itself is running on localhost.
 */
const HRIS_EMPLOYEE_IMAGE_BASE_URL =
    "https://hris.fiberathome.net/hris/admin/";


/* ============================================================
   HELPERS
============================================================ */

function readApiData<T>(
    response: unknown
): T | undefined {
    if (
        response &&
        typeof response === "object" &&
        "data" in response
    ) {
        const first =
            (
                response as {
                    data?: unknown;
                }
            ).data;

        if (
            first &&
            typeof first === "object" &&
            "data" in first
        ) {
            return (
                first as {
                    data?: T;
                }
            ).data;
        }

        return first as T;
    }

    return response as T;
}

function text(
    value:
        | string
        | null
        | undefined
): string {
    return String(value ?? "").trim();
}

function resolvePicture(
    picture:
        | string
        | null
        | undefined
): string {
    const value =
        text(picture);

    if (!value) {
        return "";
    }

    /*
     * Already a complete image source.
     */
    if (
        value.startsWith("http://") ||
        value.startsWith("https://") ||
        value.startsWith("data:") ||
        value.startsWith("blob:")
    ) {
        return value;
    }

    /*
     * employee_personal_info.picture stores a relative HRIS path,
     * normally:
     *
     *     user_images/xxxxxxxxxx.jpg
     *
     * This reproduces the exact URL construction used by the
     * previous PHP ITM application.
     */
    const clean =
        value
            .replace(/^["']+|["']+$/g, "")
            .replace(/^\/+/, "");

    return `${HRIS_EMPLOYEE_IMAGE_BASE_URL}${clean}`;
}

function normalizeEmployee(
    employee: EmployeeSearchRaw
): EmployeeOption {
    return {
        employee_id:
            text(
                employee.employee_id ??
                employee.EmpID
            ),

        employee_name:
            text(
                employee.employee_name ??
                employee.Name
            ),

        designation:
            text(
                employee.designation ??
                employee.Desig
            ),

        department:
            text(
                employee.department ??
                employee.department_name ??
                employee.Dept
            ),

        work_field:
            text(employee.work_field),

        phone:
            text(
                employee.official_cell ??
                employee.personal_cell
            ),

        email:
            text(
                employee.official_email ??
                employee.email
            ),

        picture:
            resolvePicture(employee.picture),
    };
}

function getInitials(
    name: string
): string {
    const parts =
        name
            .trim()
            .split(/\s+/)
            .filter(Boolean);

    if (!parts.length) {
        return "?";
    }

    if (parts.length === 1) {
        return (
            parts[0]
                ?.charAt(0)
                .toUpperCase() ??
            "?"
        );
    }

    return (
        `${parts[0]?.charAt(0) ?? ""}${parts[
            parts.length - 1
        ]?.charAt(0) ?? ""}`
    ).toUpperCase();
}

/* ============================================================
   PAGE
============================================================ */

export default function ClearanceFormPage() {
    const router = useRouter();

    const [form, setForm] =
        useState<ClearanceFormState>(
            EMPTY_FORM
        );

    const [loading, setLoading] =
        useState(false);

    const [error, setError] =
        useState("");

    /* ========================================================
       CLEARANCE CHECKLIST
    ======================================================== */

    const [
        checklist,
        setChecklist,
    ] =
        useState<ClearanceChecklistState>(
            EMPTY_CHECKLIST
        );

    /* ========================================================
       ASSIGNED DEVICE INFORMATION
    ======================================================== */

    const [
        assignedDevices,
        setAssignedDevices,
    ] =
        useState<Device[]>([]);

    const [
        devicesLoading,
        setDevicesLoading,
    ] =
        useState(false);

    const [
        devicesError,
        setDevicesError,
    ] =
        useState("");

    /* ========================================================
       EMPLOYEE SEARCH
    ======================================================== */

    const [
        employeeQuery,
        setEmployeeQuery,
    ] =
        useState("");

    const [
        employeeResults,
        setEmployeeResults,
    ] =
        useState<EmployeeOption[]>([]);

    const [
        employeeSearching,
        setEmployeeSearching,
    ] =
        useState(false);

    const [
        employeeDropdownOpen,
        setEmployeeDropdownOpen,
    ] =
        useState(false);

    const employeeRequestRef =
        useRef(0);

    /* ========================================================
       IT PERSONNEL
    ======================================================== */

    const [
        itPersonnel,
        setITPersonnel,
    ] =
        useState<ITEmployeeOption[]>([]);

    const [
        itQuery,
        setITQuery,
    ] =
        useState("");

    const [
        itLoading,
        setITLoading,
    ] =
        useState(true);

    const [
        itDropdownOpen,
        setITDropdownOpen,
    ] =
        useState(false);

    /* ========================================================
       LOAD IT PERSONNEL
    ======================================================== */

    useEffect(() => {
        let active = true;

        async function loadITPersonnel() {
            try {
                setITLoading(true);

                const response =
                    await dashboardApi
                        .troubleTicketITPersonnel();

                const data =
                    readApiData<
                        ITEmployeeRaw[]
                    >(response) ?? [];

                if (!active) {
                    return;
                }

                setITPersonnel(
                    data
                        .map(
                            (
                                employee
                            ): ITEmployeeOption => ({
                                employee_id:
                                    text(
                                        employee.employee_id
                                    ),

                                employee_name:
                                    text(
                                        employee.employee_name
                                    ),

                                designation:
                                    text(
                                        employee.designation
                                    ),

                                department:
                                    text(
                                        employee.department
                                    ),

                                picture:
                                    resolvePicture(
                                        employee.picture
                                    ),
                            })
                        )
                        .filter(
                            (
                                employee
                            ) =>
                                Boolean(
                                    employee.employee_id &&
                                    employee.employee_name
                                )
                        )
                );
            } catch (reason) {
                console.error(
                    "Unable to load IT personnel:",
                    reason
                );
            } finally {
                if (active) {
                    setITLoading(false);
                }
            }
        }

        void loadITPersonnel();

        return () => {
            active = false;
        };
    }, []);

    /* ========================================================
       EMPLOYEE SEARCH - DEBOUNCED
    ======================================================== */

    useEffect(() => {
        const query =
            employeeQuery.trim();

        if (
            form.employee_id &&
            query === form.employee_name
        ) {
            setEmployeeResults([]);
            return;
        }

        if (query.length < 2) {
            setEmployeeResults([]);
            setEmployeeSearching(false);
            return;
        }

        const requestNumber =
            ++employeeRequestRef.current;

        const timer =
            window.setTimeout(
                async () => {
                    try {
                        setEmployeeSearching(true);

                        const response =
                            await api.get<
                                ApiOk<
                                    EmployeeSearchRaw[]
                                >
                            >(
                                `/employees/search?q=${encodeURIComponent(
                                    query
                                )}`
                            );

                        if (
                            requestNumber !==
                            employeeRequestRef.current
                        ) {
                            return;
                        }

                        const raw =
                            readApiData<
                                EmployeeSearchRaw[]
                            >(response) ?? [];

                        const results =
                            raw
                                .map(
                                    normalizeEmployee
                                )
                                .filter(
                                    (
                                        employee
                                    ) =>
                                        Boolean(
                                            employee.employee_id &&
                                            employee.employee_name
                                        )
                                );

                        setEmployeeResults(
                            results
                        );

                        setEmployeeDropdownOpen(
                            true
                        );
                    } catch (reason) {
                        console.error(
                            "Employee search failed:",
                            reason
                        );

                        if (
                            requestNumber ===
                            employeeRequestRef.current
                        ) {
                            setEmployeeResults(
                                []
                            );
                        }
                    } finally {
                        if (
                            requestNumber ===
                            employeeRequestRef.current
                        ) {
                            setEmployeeSearching(
                                false
                            );
                        }
                    }
                },
                300
            );

        return () => {
            window.clearTimeout(timer);
        };
    }, [
        employeeQuery,
        form.employee_id,
        form.employee_name,
    ]);

    /* ========================================================
       IT SEARCH
    ======================================================== */

    const filteredITPersonnel =
        useMemo(() => {
            const query =
                itQuery
                    .trim()
                    .toLowerCase();

            if (!query) {
                return itPersonnel;
            }

            return itPersonnel.filter(
                (employee) => {
                    const haystack =
                        [
                            employee.employee_id,
                            employee.employee_name,
                            employee.designation,
                            employee.department,
                        ]
                            .join(" ")
                            .toLowerCase();

                    return haystack.includes(
                        query
                    );
                }
            );
        }, [
            itPersonnel,
            itQuery,
        ]);

    /* ========================================================
       LOAD DEVICES ASSIGNED TO SELECTED EMPLOYEE
    ======================================================== */

    async function loadAssignedDevices(
        employeeID: string
    ) {
        const id =
            employeeID.trim();

        if (!id) {
            setAssignedDevices([]);
            setDevicesError("");
            return;
        }

        try {
            setDevicesLoading(true);
            setDevicesError("");

            const response =
                await deviceApi.byEmployee(
                    id
                );

            const devices =
                readApiData<Device[]>(
                    response
                ) ?? [];

            /*
             * /devices/employee/:empId is the existing employee
             * device endpoint. Keep the API response as the source
             * of truth and simply show every device it returns.
             */
            setAssignedDevices(
                devices
            );
        } catch (reason) {
            console.error(
                "Unable to load assigned devices:",
                reason
            );

            setAssignedDevices([]);

            setDevicesError(
                reason instanceof Error
                    ? reason.message
                    : "Unable to load assigned device information."
            );
        } finally {
            setDevicesLoading(false);
        }
    }

    /* ========================================================
       SELECT EMPLOYEE
    ======================================================== */

    async function selectEmployee(
        employee: EmployeeOption
    ) {
        setForm(
            (previous) => ({
                ...previous,

                employee_id:
                    employee.employee_id,

                employee_name:
                    employee.employee_name,

                designation:
                    employee.designation,

                department:
                    employee.department,

                work_field:
                    employee.work_field,

                phone:
                    employee.phone,

                email:
                    employee.email,

                employee_picture:
                    employee.picture,
            })
        );

        setEmployeeQuery(
            employee.employee_name
        );

        setEmployeeResults([]);
        setEmployeeDropdownOpen(false);
        setError("");

        /*
         * Load all IT equipment currently returned by the
         * employee-device endpoint and show it in this page.
         */
        void loadAssignedDevices(
            employee.employee_id
        );

        try {
            const response =
                await api.get<
                    ApiOk<EmployeeDetailsRaw>
                >(
                    `/employees/${encodeURIComponent(
                        employee.employee_id
                    )}`
                );

            const details =
                readApiData<EmployeeDetailsRaw>(
                    response
                );

            if (!details) {
                return;
            }

            setForm(
                (previous) => {
                    if (
                        previous.employee_id !==
                        employee.employee_id
                    ) {
                        return previous;
                    }

                    return {
                        ...previous,

                        employee_name:
                            text(
                                details.employee_name
                            ) ||
                            previous.employee_name,

                        designation:
                            text(
                                details.designation
                            ) ||
                            previous.designation,

                        department:
                            text(
                                details.department ??
                                details.department_name
                            ) ||
                            previous.department,

                        work_field:
                            text(
                                details.work_field
                            ) ||
                            previous.work_field,

                        phone:
                            text(
                                details.official_cell ??
                                details.personal_cell
                            ) ||
                            previous.phone,

                        email:
                            text(
                                details.official_email ??
                                details.email
                            ) ||
                            previous.email,

                        employee_picture:
                            resolvePicture(
                                details.picture
                            ) ||
                            previous.employee_picture,
                    };
                }
            );
        } catch (reason) {
            console.error(
                "Unable to load employee details:",
                reason
            );
        }
    }

    function clearEmployee() {
        employeeRequestRef.current++;

        setEmployeeQuery("");
        setEmployeeResults([]);
        setEmployeeDropdownOpen(false);

        setAssignedDevices([]);
        setDevicesError("");
        setDevicesLoading(false);
        setChecklist(
            EMPTY_CHECKLIST
        );

        setForm(
            (previous) => ({
                ...previous,

                employee_id: "",
                employee_name: "",
                designation: "",
                department: "",
                work_field: "",
                phone: "",
                email: "",
                employee_picture: "",
            })
        );
    }

    /* ========================================================
       SELECT IT PERSON
    ======================================================== */

    function selectITPerson(
        employee: ITEmployeeOption
    ) {
        if (
            employee.employee_id ===
            form.employee_id
        ) {
            setError(
                "The resigning employee cannot be assigned to complete their own clearance."
            );

            return;
        }

        setForm(
            (previous) => ({
                ...previous,

                assigned_to:
                    employee.employee_id,

                assigned_to_name:
                    employee.employee_name,
            })
        );

        setITQuery(
            employee.employee_name
        );

        setITDropdownOpen(false);
        setError("");
    }

    function clearITPerson() {
        setITQuery("");
        setITDropdownOpen(false);

        setForm(
            (previous) => ({
                ...previous,

                assigned_to: "",
                assigned_to_name: "",
            })
        );
    }

    /* ========================================================
       CLEARANCE CHECKLIST
    ======================================================== */

    function handleChecklistChange(
        field: keyof ClearanceChecklistState,
        checked: boolean
    ) {
        setChecklist(
            (previous) => ({
                ...previous,
                [field]: checked,
            })
        );
    }

    const checklistSteps = [
        checklist.device_returned,
        checklist.vpn_removed,
        checklist.ip_phone_disabled,
        checklist.printer_access_removed,
        checklist.panda_removed,
    ];

    const checklistCompleted =
        checklistSteps.filter(Boolean).length;

    const checklistProgress =
        (
            checklistCompleted /
            checklistSteps.length
        ) * 100;

    const allChecklistCompleted =
        checklistCompleted ===
        checklistSteps.length;

    /* ========================================================
       VALIDATION
    ======================================================== */

    const isFormValid =
        Boolean(
            form.employee_id &&
            form.employee_name &&
            form.assigned_to &&
            form.assigned_to_name &&
            form.resignation_date
        ) &&
        form.employee_id !==
        form.assigned_to;

    /* ========================================================
       SUBMIT
    ======================================================== */

    async function handleSubmit() {
        if (!form.employee_id) {
            setError(
                "Please select the employee who will resign."
            );
            return;
        }

        if (!form.assigned_to) {
            setError(
                "Please select the IT person responsible for this clearance."
            );
            return;
        }

        if (
            form.employee_id ===
            form.assigned_to
        ) {
            setError(
                "The resigning employee cannot be assigned to complete their own clearance."
            );
            return;
        }

        if (!form.resignation_date) {
            setError(
                "Please select the resignation date."
            );
            return;
        }

        try {
            setLoading(true);
            setError("");

            const response =
                await api.post<
                    ApiOk<CreateClearanceResult>
                >(
                    "/device-clearances",
                    {
                        employee_id:
                            form.employee_id,

                        assigned_to:
                            form.assigned_to,

                        resignation_date:
                            form.resignation_date,

                        separation_mode:
                            form.separation_mode,

                        remarks:
                            form.remarks.trim(),

                        device_returned:
                            checklist.device_returned,

                        vpn_removed:
                            checklist.vpn_removed,

                        ip_phone_disabled:
                            checklist.ip_phone_disabled,

                        printer_access_removed:
                            checklist.printer_access_removed,

                        panda_removed:
                            checklist.panda_removed,
                    }
                );

            const result =
                readApiData<CreateClearanceResult>(
                    response
                );

            if (!result?.id) {
                throw new Error(
                    "Clearance was created but no clearance ID was returned."
                );
            }

            router.push(
                `/dashboard/device-clearance/approval/${result.id}`
            );
        } catch (reason) {
            setError(
                reason instanceof Error
                    ? reason.message
                    : "Unable to create device clearance."
            );
        } finally {
            setLoading(false);
        }
    }

    /* ========================================================
       UI
    ======================================================== */

    return (
        <div className="w-full p-4 sm:p-6">
            <div className="mx-auto w-full max-w-[1600px] space-y-4">

                {/* HEADER */}

                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h1 className="text-xl font-semibold text-foreground">
                            Device Clearance
                        </h1>

                        <p className="mt-1 text-sm text-muted-foreground">
                            Create and assign IT exit clearance for a resigning employee.
                        </p>
                    </div>

                    <div
                        className={`
                            inline-flex
                            w-fit
                            items-center
                            gap-1.5
                            rounded-full
                            border
                            px-3
                            py-1.5
                            text-xs
                            font-semibold
                            ${isFormValid
                                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                : "border-amber-200 bg-amber-50 text-amber-700"
                            }
                        `}
                    >
                        {isFormValid ? (
                            <CheckCircle2 className="h-3.5 w-3.5" />
                        ) : (
                            <UserRound className="h-3.5 w-3.5" />
                        )}

                        {isFormValid
                            ? "Ready to Create"
                            : "Information Required"}
                    </div>
                </div>

                {/* ERROR */}

                {error && (
                    <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                        {error}
                    </div>
                )}

                {/* EMPLOYEE INFORMATION */}

                <section className="overflow-visible rounded-2xl border border-border bg-card shadow-sm">
                    <div className="border-b border-border px-5 py-4">
                        <h2 className="text-sm font-semibold text-foreground">
                            Employee Who Will Resign
                        </h2>

                        <p className="mt-1 text-xs text-muted-foreground">
                            Search the employee from HRIS. Employee information will be populated automatically.
                        </p>
                    </div>

                    <div className="p-5">
                        <div className="grid gap-5 xl:grid-cols-[170px_minmax(0,1fr)]">

                            {/* EMPLOYEE PHOTO */}

                            <div className="flex flex-col items-center justify-start">
                                <EmployeeAvatar
                                    name={
                                        form.employee_name
                                    }
                                    picture={
                                        form.employee_picture
                                    }
                                    large
                                />

                                {form.employee_id && (
                                    <div className="mt-3 text-center">
                                        <div className="text-sm font-semibold text-foreground">
                                            {
                                                form.employee_name
                                            }
                                        </div>

                                        <div className="mt-0.5 text-xs font-medium text-primary">
                                            {
                                                form.employee_id
                                            }
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* EMPLOYEE FIELDS */}

                            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">

                                {/* EMPLOYEE SEARCH */}

                                <div className="relative md:col-span-2 xl:col-span-2">
                                    <FieldLabel required>
                                        Employee Name
                                    </FieldLabel>

                                    <div className="relative">
                                        <Search
                                            className="
                                                absolute
                                                left-3
                                                top-1/2
                                                z-10
                                                h-4
                                                w-4
                                                -translate-y-1/2
                                                text-muted-foreground
                                            "
                                        />

                                        <Input
                                            value={
                                                employeeQuery
                                            }
                                            autoComplete="off"
                                            placeholder="Search employee by name or employee ID..."
                                            className="h-10 pl-9 pr-10"
                                            onFocus={() => {
                                                if (
                                                    employeeQuery
                                                        .trim()
                                                        .length >=
                                                    2
                                                ) {
                                                    setEmployeeDropdownOpen(
                                                        true
                                                    );
                                                }
                                            }}
                                            onChange={(
                                                event
                                            ) => {
                                                const value =
                                                    event
                                                        .target
                                                        .value;

                                                setEmployeeQuery(
                                                    value
                                                );

                                                if (
                                                    form.employee_id &&
                                                    value !==
                                                    form.employee_name
                                                ) {
                                                    setAssignedDevices([]);
                                                    setDevicesError("");
                                                    setChecklist(
                                                        EMPTY_CHECKLIST
                                                    );

                                                    setForm(
                                                        (
                                                            previous
                                                        ) => ({
                                                            ...previous,

                                                            employee_id:
                                                                "",

                                                            employee_name:
                                                                "",

                                                            designation:
                                                                "",

                                                            department:
                                                                "",

                                                            work_field:
                                                                "",

                                                            phone:
                                                                "",

                                                            email:
                                                                "",

                                                            employee_picture:
                                                                "",
                                                        })
                                                    );
                                                }

                                                setEmployeeDropdownOpen(
                                                    true
                                                );
                                            }}
                                            onBlur={() => {
                                                window.setTimeout(
                                                    () =>
                                                        setEmployeeDropdownOpen(
                                                            false
                                                        ),
                                                    180
                                                );
                                            }}
                                        />

                                        {employeeSearching ? (
                                            <Loader2
                                                className="
                                                    absolute
                                                    right-3
                                                    top-1/2
                                                    h-4
                                                    w-4
                                                    -translate-y-1/2
                                                    animate-spin
                                                    text-primary
                                                "
                                            />
                                        ) : form.employee_id ? (
                                            <button
                                                type="button"
                                                aria-label="Clear employee"
                                                onMouseDown={(
                                                    event
                                                ) => {
                                                    event.preventDefault();
                                                }}
                                                onClick={
                                                    clearEmployee
                                                }
                                                className="
                                                    absolute
                                                    right-2.5
                                                    top-1/2
                                                    -translate-y-1/2
                                                    rounded-md
                                                    p-1
                                                    text-muted-foreground
                                                    transition
                                                    hover:bg-muted
                                                    hover:text-foreground
                                                "
                                            >
                                                <X className="h-4 w-4" />
                                            </button>
                                        ) : null}

                                        {employeeDropdownOpen &&
                                            employeeQuery
                                                .trim()
                                                .length >=
                                            2 && (
                                                <div
                                                    className="
                                                        absolute
                                                        left-0
                                                        right-0
                                                        top-[calc(100%+6px)]
                                                        z-[80]
                                                        max-h-[420px]
                                                        overflow-y-auto
                                                        rounded-xl
                                                        border
                                                        border-border
                                                        bg-popover
                                                        shadow-xl
                                                    "
                                                >
                                                    {employeeSearching &&
                                                        employeeResults.length ===
                                                        0 ? (
                                                        <div className="flex items-center justify-center gap-2 px-4 py-8 text-sm text-muted-foreground">
                                                            <Loader2 className="h-4 w-4 animate-spin" />
                                                            Searching employees...
                                                        </div>
                                                    ) : employeeResults.length >
                                                        0 ? (
                                                        <div className="divide-y divide-border">
                                                            {employeeResults.map(
                                                                (
                                                                    employee
                                                                ) => (
                                                                    <button
                                                                        key={
                                                                            employee.employee_id
                                                                        }
                                                                        type="button"
                                                                        onMouseDown={(
                                                                            event
                                                                        ) => {
                                                                            event.preventDefault();
                                                                        }}
                                                                        onClick={() =>
                                                                            void selectEmployee(
                                                                                employee
                                                                            )
                                                                        }
                                                                        className="
                                                                            flex
                                                                            w-full
                                                                            items-center
                                                                            gap-3
                                                                            px-4
                                                                            py-3
                                                                            text-left
                                                                            transition-colors
                                                                            hover:bg-muted/70
                                                                        "
                                                                    >
                                                                        <EmployeeAvatar
                                                                            name={
                                                                                employee.employee_name
                                                                            }
                                                                            picture={
                                                                                employee.picture
                                                                            }
                                                                        />

                                                                        <div className="min-w-0 flex-1">
                                                                            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                                                                                <span className="text-sm font-semibold text-foreground">
                                                                                    {
                                                                                        employee.employee_name
                                                                                    }
                                                                                </span>

                                                                                <span className="text-xs font-medium text-primary">
                                                                                    (
                                                                                    {
                                                                                        employee.employee_id
                                                                                    }
                                                                                    )
                                                                                </span>
                                                                            </div>

                                                                            <div className="mt-1 line-clamp-1 text-xs font-medium text-muted-foreground">
                                                                                {employee.department ||
                                                                                    employee.designation ||
                                                                                    "Employee"}
                                                                            </div>

                                                                            {employee.designation &&
                                                                                employee.department && (
                                                                                    <div className="mt-0.5 line-clamp-1 text-[11px] text-muted-foreground/80">
                                                                                        {
                                                                                            employee.designation
                                                                                        }
                                                                                    </div>
                                                                                )}
                                                                        </div>
                                                                    </button>
                                                                )
                                                            )}
                                                        </div>
                                                    ) : (
                                                        !employeeSearching && (
                                                            <div className="px-4 py-8 text-center">
                                                                <UserRound className="mx-auto h-7 w-7 text-muted-foreground/60" />

                                                                <div className="mt-2 text-sm font-medium text-foreground">
                                                                    No employee found
                                                                </div>

                                                                <div className="mt-1 text-xs text-muted-foreground">
                                                                    Search using employee name or employee ID.
                                                                </div>
                                                            </div>
                                                        )
                                                    )}
                                                </div>
                                            )}
                                    </div>
                                </div>

                                <ReadOnlyField
                                    label="Employee ID"
                                    required
                                    value={
                                        form.employee_id
                                    }
                                    placeholder="Auto-filled"
                                />

                                <ReadOnlyField
                                    label="Designation"
                                    value={
                                        form.designation
                                    }
                                    placeholder="Auto-filled"
                                />

                                <ReadOnlyField
                                    label="Department"
                                    value={
                                        form.department
                                    }
                                    placeholder="Auto-filled"
                                />

                                <ReadOnlyField
                                    label="Work Field"
                                    value={
                                        form.work_field
                                    }
                                    placeholder="Auto-filled"
                                />

                                <ReadOnlyField
                                    label="Phone"
                                    value={
                                        form.phone
                                    }
                                    placeholder="Auto-filled"
                                />

                                <ReadOnlyField
                                    label="Email"
                                    value={
                                        form.email
                                    }
                                    placeholder="Auto-filled"
                                />

                                <div>
                                    <FieldLabel required>
                                        Resignation / Last Working Date
                                    </FieldLabel>

                                    <div className="relative">
                                        <CalendarDays
                                            className="
                                                pointer-events-none
                                                absolute
                                                left-3
                                                top-1/2
                                                h-4
                                                w-4
                                                -translate-y-1/2
                                                text-muted-foreground
                                            "
                                        />

                                        <Input
                                            type="date"
                                            value={
                                                form.resignation_date
                                            }
                                            className="h-10 pl-9"
                                            onChange={(
                                                event
                                            ) =>
                                                setForm(
                                                    (
                                                        previous
                                                    ) => ({
                                                        ...previous,

                                                        resignation_date:
                                                            event
                                                                .target
                                                                .value,
                                                    })
                                                )
                                            }
                                        />
                                    </div>
                                </div>

                                <div>
                                    <FieldLabel>
                                        Separation Mode
                                    </FieldLabel>

                                    <select
                                        value={
                                            form.separation_mode
                                        }
                                        onChange={(
                                            event
                                        ) =>
                                            setForm(
                                                (
                                                    previous
                                                ) => ({
                                                    ...previous,

                                                    separation_mode:
                                                        event
                                                            .target
                                                            .value,
                                                })
                                            )
                                        }
                                        className="
                                            h-10
                                            w-full
                                            rounded-md
                                            border
                                            border-input
                                            bg-background
                                            px-3
                                            text-sm
                                            text-foreground
                                            outline-none
                                            transition
                                            focus:border-primary
                                            focus:ring-2
                                            focus:ring-primary/20
                                        "
                                    >
                                        <option value="Resignation">
                                            Resignation
                                        </option>

                                        <option value="Retirement">
                                            Retirement
                                        </option>

                                        <option value="Contract End">
                                            Contract End
                                        </option>

                                        <option value="Termination">
                                            Termination
                                        </option>

                                        <option value="Other">
                                            Other
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* ==================================================
                    ASSIGNED DEVICE INFORMATION
                ================================================== */}

                <section className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
                    <div className="flex flex-col gap-2 border-b border-border px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h2 className="flex items-center gap-2 text-sm font-semibold text-foreground">
                                <HardDrive className="h-4 w-4 text-primary" />
                                Assigned Device Information
                            </h2>

                            <p className="mt-1 text-xs text-muted-foreground">
                                IT equipment currently linked to the selected employee.
                            </p>
                        </div>

                        {form.employee_id && !devicesLoading && (
                            <span
                                className="
                                    inline-flex
                                    w-fit
                                    items-center
                                    rounded-full
                                    border
                                    border-primary/15
                                    bg-primary/5
                                    px-2.5
                                    py-1
                                    text-[11px]
                                    font-semibold
                                    text-primary
                                "
                            >
                                {assignedDevices.length}{" "}
                                {assignedDevices.length === 1
                                    ? "device"
                                    : "devices"}
                            </span>
                        )}
                    </div>

                    <div className="p-5">
                        {!form.employee_id ? (
                            <div
                                className="
                                    flex
                                    min-h-[120px]
                                    flex-col
                                    items-center
                                    justify-center
                                    rounded-xl
                                    border
                                    border-dashed
                                    border-border
                                    bg-muted/15
                                    px-4
                                    text-center
                                "
                            >
                                <HardDrive className="h-8 w-8 text-muted-foreground/40" />

                                <p className="mt-2 text-sm font-medium text-foreground">
                                    Select an employee first
                                </p>

                                <p className="mt-1 text-xs text-muted-foreground">
                                    Assigned device information will load automatically after employee selection.
                                </p>
                            </div>
                        ) : devicesLoading ? (
                            <div
                                className="
                                    flex
                                    min-h-[120px]
                                    items-center
                                    justify-center
                                    gap-2
                                    rounded-xl
                                    border
                                    border-border
                                    bg-muted/15
                                    text-sm
                                    text-muted-foreground
                                "
                            >
                                <Loader2 className="h-4 w-4 animate-spin text-primary" />
                                Loading assigned devices...
                            </div>
                        ) : devicesError ? (
                            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-4">
                                <p className="text-sm font-medium text-red-700">
                                    Unable to load assigned devices
                                </p>

                                <p className="mt-1 text-xs text-red-600">
                                    {devicesError}
                                </p>

                                <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    className="mt-3"
                                    onClick={() =>
                                        void loadAssignedDevices(
                                            form.employee_id
                                        )
                                    }
                                >
                                    Try Again
                                </Button>
                            </div>
                        ) : assignedDevices.length === 0 ? (
                            <div
                                className="
                                    flex
                                    min-h-[120px]
                                    flex-col
                                    items-center
                                    justify-center
                                    rounded-xl
                                    border
                                    border-dashed
                                    border-emerald-200
                                    bg-emerald-50/50
                                    px-4
                                    text-center
                                "
                            >
                                <PackageOpen className="h-8 w-8 text-emerald-600/70" />

                                <p className="mt-2 text-sm font-semibold text-emerald-800">
                                    No assigned IT device found
                                </p>

                                <p className="mt-1 text-xs text-emerald-700/80">
                                    The employee-device endpoint returned no equipment for this employee.
                                </p>
                            </div>
                        ) : (
                            <div className="overflow-hidden rounded-xl border border-border">
                                <div className="overflow-x-auto">
                                    <table className="w-full min-w-[920px] border-collapse">
                                        <thead className="bg-muted/40">
                                            <tr className="border-b border-border">
                                                <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                                                    Device
                                                </th>

                                                <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                                                    Brand / Model
                                                </th>

                                                <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                                                    Serial Number
                                                </th>

                                                <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                                                    Status
                                                </th>

                                                <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                                                    Assigned Date
                                                </th>

                                                <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                                                    IP Address
                                                </th>

                                                <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                                                    Specification
                                                </th>
                                            </tr>
                                        </thead>

                                        <tbody className="divide-y divide-border">
                                            {assignedDevices.map(
                                                (
                                                    device
                                                ) => (
                                                    <tr
                                                        key={
                                                            device.id
                                                        }
                                                        className="bg-card transition-colors hover:bg-muted/20"
                                                    >
                                                        <td className="px-4 py-3 align-top">
                                                            <div className="flex items-center gap-2.5">
                                                                <div
                                                                    className="
                                                                        flex
                                                                        h-9
                                                                        w-9
                                                                        shrink-0
                                                                        items-center
                                                                        justify-center
                                                                        rounded-lg
                                                                        border
                                                                        border-primary/10
                                                                        bg-primary/5
                                                                    "
                                                                >
                                                                    <HardDrive className="h-4 w-4 text-primary" />
                                                                </div>

                                                                <div className="min-w-0">
                                                                    <p className="font-medium text-foreground">
                                                                        {text(
                                                                            device.category
                                                                        ) ||
                                                                            "Device"}
                                                                    </p>

                                                                    <p className="mt-0.5 text-[11px] text-muted-foreground">
                                                                        Asset ID:{" "}
                                                                        {
                                                                            device.id
                                                                        }
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </td>

                                                        <td className="px-4 py-3 align-top">
                                                            <p className="text-sm font-medium text-foreground">
                                                                {text(
                                                                    device.brand
                                                                ) ||
                                                                    "—"}
                                                            </p>

                                                            <p className="mt-0.5 text-xs text-muted-foreground">
                                                                {text(
                                                                    device.model_no
                                                                ) ||
                                                                    "No model"}
                                                            </p>
                                                        </td>

                                                        <td className="px-4 py-3 align-top">
                                                            <span className="font-mono text-xs font-medium text-foreground">
                                                                {text(
                                                                    device.device_serial
                                                                ) ||
                                                                    "—"}
                                                            </span>
                                                        </td>

                                                        <td className="px-4 py-3 align-top">
                                                            <DeviceStatusBadge
                                                                status={
                                                                    device.status
                                                                }
                                                            />
                                                        </td>

                                                        <td className="px-4 py-3 align-top text-xs text-foreground">
                                                            {formatDeviceDate(
                                                                device.assign_date
                                                            )}
                                                        </td>

                                                        <td className="px-4 py-3 align-top">
                                                            <span className="font-mono text-xs text-foreground">
                                                                {text(
                                                                    device.ip_address
                                                                ) ||
                                                                    "—"}
                                                            </span>
                                                        </td>

                                                        <td className="px-4 py-3 align-top">
                                                            <div className="space-y-0.5 text-[11px] text-muted-foreground">
                                                                {text(
                                                                    device.cpu
                                                                ) && (
                                                                        <p>
                                                                            CPU:{" "}
                                                                            {
                                                                                device.cpu
                                                                            }
                                                                        </p>
                                                                    )}

                                                                {text(
                                                                    device.ram
                                                                ) && (
                                                                        <p>
                                                                            RAM:{" "}
                                                                            {
                                                                                device.ram
                                                                            }
                                                                        </p>
                                                                    )}

                                                                {text(
                                                                    device.hdd
                                                                ) && (
                                                                        <p>
                                                                            Storage:{" "}
                                                                            {
                                                                                device.hdd
                                                                            }
                                                                        </p>
                                                                    )}

                                                                {!text(
                                                                    device.cpu
                                                                ) &&
                                                                    !text(
                                                                        device.ram
                                                                    ) &&
                                                                    !text(
                                                                        device.hdd
                                                                    ) && (
                                                                        <span>
                                                                            —
                                                                        </span>
                                                                    )}
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}
                    </div>
                </section>

                {/* ==================================================
                    CLEARANCE CHECKLIST
                ================================================== */}

                <section className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
                    <div className="flex flex-col gap-2 border-b border-border px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h2 className="text-sm font-semibold text-foreground">
                                IT Clearance Checklist
                            </h2>

                            <p className="mt-1 text-xs text-muted-foreground">
                                Mark each return and access-removal step as it is completed.
                            </p>
                        </div>

                        <span
                            className={`
                                inline-flex
                                w-fit
                                rounded-full
                                border
                                px-2.5
                                py-1
                                text-[11px]
                                font-semibold
                                ${allChecklistCompleted
                                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                    : checklistCompleted > 0
                                        ? "border-amber-200 bg-amber-50 text-amber-700"
                                        : "border-border bg-muted/30 text-muted-foreground"
                                }
                            `}
                        >
                            {checklistCompleted}/5 completed
                        </span>
                    </div>

                    <div className="p-5">
                        <div className="overflow-hidden rounded-xl border border-border divide-y divide-border">
                            <ClearanceChecklistRow
                                label="Device Returned"
                                desc={
                                    assignedDevices.length > 0
                                        ? `Confirm return of all assigned IT equipment (${assignedDevices.length} device${assignedDevices.length === 1 ? "" : "s"} currently linked).`
                                        : "Confirm the employee has returned all assigned IT equipment."
                                }
                                checked={
                                    checklist.device_returned
                                }
                                disabled={
                                    !form.employee_id
                                }
                                onChange={(
                                    value
                                ) =>
                                    handleChecklistChange(
                                        "device_returned",
                                        value
                                    )
                                }
                            />

                            <ClearanceChecklistRow
                                label="VPN Access Removed"
                                desc="VPN profile/account access has been revoked."
                                checked={
                                    checklist.vpn_removed
                                }
                                disabled={
                                    !form.employee_id
                                }
                                onChange={(
                                    value
                                ) =>
                                    handleChecklistChange(
                                        "vpn_removed",
                                        value
                                    )
                                }
                            />

                            <ClearanceChecklistRow
                                label="IP Phone Disabled"
                                desc="IP phone extension or voice service has been disabled."
                                checked={
                                    checklist.ip_phone_disabled
                                }
                                disabled={
                                    !form.employee_id
                                }
                                onChange={(
                                    value
                                ) =>
                                    handleChecklistChange(
                                        "ip_phone_disabled",
                                        value
                                    )
                                }
                            />

                            <ClearanceChecklistRow
                                label="Printer Access Removed"
                                desc="Printer / print-server access has been revoked."
                                checked={
                                    checklist.printer_access_removed
                                }
                                disabled={
                                    !form.employee_id
                                }
                                onChange={(
                                    value
                                ) =>
                                    handleChecklistChange(
                                        "printer_access_removed",
                                        value
                                    )
                                }
                            />

                            <ClearanceChecklistRow
                                label="Endpoint Security Removed"
                                desc="Panda / endpoint-security profile has been removed where applicable."
                                checked={
                                    checklist.panda_removed
                                }
                                disabled={
                                    !form.employee_id
                                }
                                onChange={(
                                    value
                                ) =>
                                    handleChecklistChange(
                                        "panda_removed",
                                        value
                                    )
                                }
                            />
                        </div>

                        <div className="mt-4">
                            <div className="mb-1.5 flex items-center justify-between text-xs">
                                <span className="font-medium text-foreground">
                                    Progress
                                </span>

                                <span className="font-semibold tabular-nums text-muted-foreground">
                                    {checklistCompleted}/5
                                </span>
                            </div>

                            <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                                <div
                                    className="h-full rounded-full bg-primary transition-all duration-300"
                                    style={{
                                        width: `${checklistProgress}%`,
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </section>

                {/* CLEARANCE ASSIGNMENT */}

                <section className="overflow-visible rounded-2xl border border-border bg-card shadow-sm">
                    <div className="border-b border-border px-5 py-4">
                        <h2 className="text-sm font-semibold text-foreground">
                            Clearance Assignment
                        </h2>

                        <p className="mt-1 text-xs text-muted-foreground">
                            Select the IT employee who will be responsible for completing this clearance.
                        </p>
                    </div>

                    <div className="p-5">
                        <div className="grid gap-4 lg:grid-cols-2">
                            <div className="relative">
                                <FieldLabel required>
                                    Assigned IT Person
                                </FieldLabel>

                                <div className="relative">
                                    <Search
                                        className="
                                            absolute
                                            left-3
                                            top-1/2
                                            z-10
                                            h-4
                                            w-4
                                            -translate-y-1/2
                                            text-muted-foreground
                                        "
                                    />

                                    <Input
                                        value={
                                            itQuery
                                        }
                                        placeholder={
                                            itLoading
                                                ? "Loading IT personnel..."
                                                : "Search IT personnel..."
                                        }
                                        disabled={
                                            itLoading
                                        }
                                        autoComplete="off"
                                        className="h-10 pl-9 pr-10"
                                        onFocus={() =>
                                            setITDropdownOpen(
                                                true
                                            )
                                        }
                                        onChange={(
                                            event
                                        ) => {
                                            setITQuery(
                                                event
                                                    .target
                                                    .value
                                            );

                                            if (
                                                form.assigned_to
                                            ) {
                                                setForm(
                                                    (
                                                        previous
                                                    ) => ({
                                                        ...previous,

                                                        assigned_to:
                                                            "",

                                                        assigned_to_name:
                                                            "",
                                                    })
                                                );
                                            }

                                            setITDropdownOpen(
                                                true
                                            );
                                        }}
                                        onBlur={() => {
                                            window.setTimeout(
                                                () =>
                                                    setITDropdownOpen(
                                                        false
                                                    ),
                                                180
                                            );
                                        }}
                                    />

                                    {itLoading ? (
                                        <Loader2
                                            className="
                                                absolute
                                                right-3
                                                top-1/2
                                                h-4
                                                w-4
                                                -translate-y-1/2
                                                animate-spin
                                                text-primary
                                            "
                                        />
                                    ) : form.assigned_to ? (
                                        <button
                                            type="button"
                                            aria-label="Clear assigned IT person"
                                            onMouseDown={(
                                                event
                                            ) =>
                                                event.preventDefault()
                                            }
                                            onClick={
                                                clearITPerson
                                            }
                                            className="
                                                absolute
                                                right-2.5
                                                top-1/2
                                                -translate-y-1/2
                                                rounded-md
                                                p-1
                                                text-muted-foreground
                                                hover:bg-muted
                                                hover:text-foreground
                                            "
                                        >
                                            <X className="h-4 w-4" />
                                        </button>
                                    ) : (
                                        <ChevronDown
                                            className="
                                                pointer-events-none
                                                absolute
                                                right-3
                                                top-1/2
                                                h-4
                                                w-4
                                                -translate-y-1/2
                                                text-muted-foreground
                                            "
                                        />
                                    )}

                                    {itDropdownOpen &&
                                        !itLoading && (
                                            <div
                                                className="
                                                    absolute
                                                    left-0
                                                    right-0
                                                    top-[calc(100%+6px)]
                                                    z-[70]
                                                    max-h-[360px]
                                                    overflow-y-auto
                                                    rounded-xl
                                                    border
                                                    border-border
                                                    bg-popover
                                                    shadow-xl
                                                "
                                            >
                                                {filteredITPersonnel.length >
                                                    0 ? (
                                                    <div className="divide-y divide-border">
                                                        {filteredITPersonnel.map(
                                                            (
                                                                employee
                                                            ) => {
                                                                const isSameEmployee =
                                                                    employee.employee_id ===
                                                                    form.employee_id;

                                                                return (
                                                                    <button
                                                                        key={
                                                                            employee.employee_id
                                                                        }
                                                                        type="button"
                                                                        disabled={
                                                                            isSameEmployee
                                                                        }
                                                                        onMouseDown={(
                                                                            event
                                                                        ) =>
                                                                            event.preventDefault()
                                                                        }
                                                                        onClick={() =>
                                                                            selectITPerson(
                                                                                employee
                                                                            )
                                                                        }
                                                                        className="
                                                                            flex
                                                                            w-full
                                                                            items-center
                                                                            gap-3
                                                                            px-4
                                                                            py-3
                                                                            text-left
                                                                            transition-colors
                                                                            hover:bg-muted/70
                                                                            disabled:cursor-not-allowed
                                                                            disabled:opacity-45
                                                                        "
                                                                    >
                                                                        <EmployeeAvatar
                                                                            name={
                                                                                employee.employee_name
                                                                            }
                                                                            picture={
                                                                                employee.picture
                                                                            }
                                                                        />

                                                                        <div className="min-w-0 flex-1">
                                                                            <div className="flex flex-wrap items-center gap-x-2">
                                                                                <span className="text-sm font-semibold text-foreground">
                                                                                    {
                                                                                        employee.employee_name
                                                                                    }
                                                                                </span>

                                                                                <span className="text-xs font-medium text-primary">
                                                                                    (
                                                                                    {
                                                                                        employee.employee_id
                                                                                    }
                                                                                    )
                                                                                </span>
                                                                            </div>

                                                                            <div className="mt-1 text-xs text-muted-foreground">
                                                                                {isSameEmployee
                                                                                    ? "Cannot assign resigning employee"
                                                                                    : employee.department ||
                                                                                    employee.designation ||
                                                                                    "IT"}
                                                                            </div>
                                                                        </div>
                                                                    </button>
                                                                );
                                                            }
                                                        )}
                                                    </div>
                                                ) : (
                                                    <div className="px-4 py-8 text-center text-sm text-muted-foreground">
                                                        No IT personnel found.
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                </div>
                            </div>

                            <div>
                                <FieldLabel>
                                    Selected Responsible Person
                                </FieldLabel>

                                <div
                                    className="
                                        flex
                                        min-h-10
                                        items-center
                                        rounded-md
                                        border
                                        border-input
                                        bg-muted/25
                                        px-3
                                        py-2
                                    "
                                >
                                    {form.assigned_to ? (
                                        <div className="flex min-w-0 items-center gap-2">
                                            <div
                                                className="
                                                    flex
                                                    h-7
                                                    w-7
                                                    shrink-0
                                                    items-center
                                                    justify-center
                                                    rounded-full
                                                    bg-primary/10
                                                    text-[10px]
                                                    font-bold
                                                    text-primary
                                                "
                                            >
                                                {getInitials(
                                                    form.assigned_to_name
                                                )}
                                            </div>

                                            <div className="min-w-0">
                                                <div className="truncate text-sm font-medium text-foreground">
                                                    {
                                                        form.assigned_to_name
                                                    }
                                                </div>

                                                <div className="text-[11px] text-muted-foreground">
                                                    {
                                                        form.assigned_to
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <span className="text-sm text-muted-foreground">
                                            No IT person selected
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* REMARKS */}

                <section className="rounded-2xl border border-border bg-card shadow-sm">
                    <div className="border-b border-border px-5 py-4">
                        <h2 className="text-sm font-semibold text-foreground">
                            Remarks
                        </h2>
                    </div>

                    <div className="p-5">
                        <textarea
                            value={
                                form.remarks
                            }
                            onChange={(
                                event
                            ) =>
                                setForm(
                                    (
                                        previous
                                    ) => ({
                                        ...previous,

                                        remarks:
                                            event
                                                .target
                                                .value,
                                    })
                                )
                            }
                            placeholder="Optional notes about the employee's resignation or clearance..."
                            rows={4}
                            maxLength={2000}
                            className="
                                w-full
                                resize-y
                                rounded-lg
                                border
                                border-input
                                bg-background
                                px-3
                                py-2.5
                                text-sm
                                text-foreground
                                outline-none
                                transition
                                placeholder:text-muted-foreground
                                focus:border-primary
                                focus:ring-2
                                focus:ring-primary/20
                            "
                        />

                        <div className="mt-1 text-right text-[10px] text-muted-foreground">
                            {
                                form
                                    .remarks
                                    .length
                            }
                            /2000
                        </div>
                    </div>
                </section>

                {/* WORKFLOW INFO */}

                <div className="rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
                    Creating this request will set the clearance status to{" "}
                    <strong>
                        Pending Clearance
                    </strong>
                    . The assigned IT person will complete the checklist on the clearance approval page.
                </div>

                {/* ACTIONS */}

                <div
                    className="
                        flex
                        flex-col-reverse
                        gap-2
                        border-t
                        border-border
                        pt-4
                        sm:flex-row
                        sm:items-center
                        sm:justify-end
                    "
                >
                    <Button
                        type="button"
                        variant="outline"
                        disabled={
                            loading
                        }
                        onClick={() =>
                            router.back()
                        }
                    >
                        Cancel
                    </Button>

                    <Button
                        type="button"
                        disabled={
                            !isFormValid ||
                            loading
                        }
                        onClick={() =>
                            void handleSubmit()
                        }
                        className="min-w-[180px]"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Creating...
                            </>
                        ) : (
                            <>
                                <CheckCircle2 className="mr-2 h-4 w-4" />
                                Create Clearance
                            </>
                        )}
                    </Button>
                </div>
            </div>
        </div>
    );
}

/* ============================================================
   CLEARANCE CHECKLIST ROW
============================================================ */

function ClearanceChecklistRow({
    label,
    desc,
    checked,
    disabled = false,
    onChange,
}: {
    label: string;
    desc: string;
    checked: boolean;
    disabled?: boolean;
    onChange: (
        value: boolean
    ) => void;
}) {
    return (
        <div
            className={`
                flex
                items-center
                justify-between
                gap-4
                px-4
                py-3.5
                transition-colors
                ${disabled
                    ? "bg-muted/20 opacity-60"
                    : "hover:bg-muted/25"
                }
            `}
        >
            <div className="min-w-0">
                <p className="text-sm font-medium text-foreground">
                    {label}
                </p>

                <p className="mt-0.5 text-xs leading-5 text-muted-foreground">
                    {desc}
                </p>
            </div>

            <Checkbox
                checked={
                    checked
                }
                disabled={
                    disabled
                }
                onCheckedChange={(
                    value
                ) =>
                    onChange(
                        value === true
                    )
                }
                className="h-5 w-5 shrink-0"
            />
        </div>
    );
}

/* ============================================================
   DEVICE HELPERS
============================================================ */

function formatDeviceDate(
    value:
        | string
        | null
        | undefined
): string {
    const raw =
        text(value);

    if (!raw) {
        return "—";
    }

    const date =
        new Date(raw);

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {
        return raw;
    }

    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "short",
            year: "numeric",
        }
    );
}

function DeviceStatusBadge({
    status,
}: {
    status:
    | string
    | null
    | undefined;
}) {
    const value =
        text(status) ||
        "Unknown";

    const key =
        value.toLowerCase();

    const classes =
        key === "assigned" ||
            key === "1"
            ? "border-blue-200 bg-blue-50 text-blue-700"
            : key === "returned" ||
                key === "4"
                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                : key === "transferred" ||
                    key === "transfer" ||
                    key === "3"
                    ? "border-amber-200 bg-amber-50 text-amber-700"
                    : "border-border bg-muted/40 text-muted-foreground";

    return (
        <span
            className={`
                inline-flex
                rounded-full
                border
                px-2
                py-0.5
                text-[10px]
                font-semibold
                ${classes}
            `}
        >
            {value}
        </span>
    );
}

/* ============================================================
   FIELD LABEL
============================================================ */

function FieldLabel({
    children,
    required = false,
}: {
    children:
    React.ReactNode;

    required?: boolean;
}) {
    return (
        <label className="mb-1.5 block text-xs font-semibold text-foreground">
            {children}

            {required && (
                <span className="ml-0.5 text-red-500">
                    *
                </span>
            )}
        </label>
    );
}

/* ============================================================
   READ ONLY FIELD
============================================================ */

function ReadOnlyField({
    label,
    value,
    placeholder,
    required = false,
}: {
    label: string;
    value: string;
    placeholder?: string;
    required?: boolean;
}) {
    return (
        <div>
            <FieldLabel
                required={
                    required
                }
            >
                {label}
            </FieldLabel>

            <Input
                value={
                    value
                }
                readOnly
                placeholder={
                    placeholder
                }
                className="
                    h-10
                    cursor-default
                    bg-muted/40
                    text-foreground
                "
            />
        </div>
    );
}

/* ============================================================
   EMPLOYEE AVATAR
============================================================ */

function EmployeeAvatar({
    name,
    picture,
    large = false,
}: {
    name: string;
    picture: string;
    large?: boolean;
}) {
    const [
        imageFailed,
        setImageFailed,
    ] =
        useState(false);

    useEffect(() => {
        setImageFailed(false);
    }, [
        picture,
    ]);

    const sizeClass =
        large
            ? "h-28 w-28 text-xl"
            : "h-11 w-11 text-xs";

    if (
        picture &&
        !imageFailed
    ) {
        return (
            <img
                src={
                    picture
                }
                alt={
                    name ||
                    "Employee"
                }
                loading={
                    large
                        ? "eager"
                        : "lazy"
                }
                referrerPolicy="no-referrer"
                onError={(
                    event
                ) => {
                    console.error(
                        "Unable to load HRIS employee image:",
                        picture,
                        event.currentTarget.currentSrc
                    );

                    setImageFailed(
                        true
                    );
                }}
                className={`
                    ${sizeClass}
                    shrink-0
                    rounded-full
                    border
                    border-border
                    bg-muted
                    object-cover
                    shadow-sm
                `}
            />
        );
    }

    return (
        <div
            className={`
                ${sizeClass}
                flex
                shrink-0
                items-center
                justify-center
                rounded-full
                border
                border-primary/15
                bg-primary/10
                font-bold
                text-primary
            `}
        >
            {name ? (
                getInitials(
                    name
                )
            ) : (
                <UserRound
                    className={
                        large
                            ? "h-9 w-9"
                            : "h-5 w-5"
                    }
                />
            )}
        </div>
    );
}
