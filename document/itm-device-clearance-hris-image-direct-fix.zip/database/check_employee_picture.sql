-- Check the HRIS picture path stored in PostgreSQL.

SELECT
    o.employee_id,
    o.employee_name,
    o.designation,
    o.department_name,
    p.picture,
    CASE
        WHEN COALESCE(BTRIM(p.picture), '') = ''
            THEN ''
        WHEN p.picture ~* '^https?://'
            THEN p.picture
        ELSE
            'https://hris.fiberathome.net/hris/admin/' ||
            LTRIM(BTRIM(p.picture), '/')
    END AS employee_image_url
FROM public.employee_office_info o
LEFT JOIN public.employee_personal_info p
    ON BTRIM(p.employee_id) = BTRIM(o.employee_id)
WHERE o.employee_id = '02-0501';


-- Find employees that have no picture path.

SELECT
    o.employee_id,
    o.employee_name
FROM public.employee_office_info o
LEFT JOIN public.employee_personal_info p
    ON BTRIM(p.employee_id) = BTRIM(o.employee_id)
WHERE COALESCE(BTRIM(p.picture), '') = ''
ORDER BY o.employee_name;
