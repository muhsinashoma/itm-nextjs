#!/usr/bin/env bash
set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(pwd)}"

if [ ! -d "$ROOT/frontend/app" ]; then
    echo "ERROR: frontend/app not found under: $ROOT"
    echo "Run this script from the ITM project root or pass the project root."
    exit 1
fi

if [ -d "$ROOT/itm/backend/internal/handler" ]; then
    BACKEND="$ROOT/itm/backend/internal/handler/handlers.go"
else
    BACKEND="$ROOT/backend/internal/handler/handlers.go"
fi

ACTIVE_PAGE="$ROOT/frontend/app/dashboard/device-clearance/clearance-form/page.tsx"
CREATE_PAGE="$ROOT/frontend/app/dashboard/device-clearance/create/page.tsx"

mkdir -p "$(dirname "$BACKEND")"
mkdir -p "$(dirname "$ACTIVE_PAGE")"
mkdir -p "$(dirname "$CREATE_PAGE")"

for file in "$BACKEND" "$ACTIVE_PAGE" "$CREATE_PAGE"; do
    if [ -f "$file" ]; then
        cp "$file" "$file.bak"
        echo "Backup: $file.bak"
    fi
done

cp \
    "$PKG_DIR/itm/backend/internal/handler/handlers.go" \
    "$BACKEND"

cp \
    "$PKG_DIR/frontend/app/dashboard/device-clearance/clearance-form/page.tsx" \
    "$ACTIVE_PAGE"

cp \
    "$PKG_DIR/frontend/app/dashboard/device-clearance/create/page.tsx" \
    "$CREATE_PAGE"

echo
echo "Installed Device Clearance HRIS employee image fix."
echo
echo "The frontend now builds image URLs as:"
echo "https://hris.fiberathome.net/hris/admin/<employee_personal_info.picture>"
echo
echo "Restart backend and frontend."
